import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Key,
  Mail,
  Video,
  Shield,
  Users,
  Heart,
  Bug,
  Gamepad2,
  Footprints,
  Wifi,
  BookOpen,
  Clock,
  ChevronRight,
} from "lucide-react"

export const metadata = {
  title: "Lessons | CyberSafe Academy",
  description: "Comprehensive digital security lessons covering passwords, phishing, deepfakes, privacy, and more.",
}

const lessons = [
  {
    title: "Password Security & 2FA",
    description: "Learn how to create unbreakable passwords and protect your accounts with two-factor authentication",
    icon: Key,
    href: "/lessons/passwords",
    duration: "15 min",
    difficulty: "Beginner",
    color: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
    topics: ["Strong passwords", "Password managers", "Two-factor authentication", "Account recovery"],
  },
  {
    title: "Phishing & Scams",
    description: "Recognize and avoid fake emails, messages, websites, and social engineering attacks",
    icon: Mail,
    href: "/lessons/phishing",
    duration: "20 min",
    difficulty: "Intermediate",
    color: "bg-red-500/10 text-red-600 dark:text-red-400",
    topics: ["Email phishing", "Fake websites", "Social engineering", "Reporting scams"],
  },
  {
    title: "Deepfakes & Misinformation",
    description: "Understand AI-generated fake content and learn to verify what you see online",
    icon: Video,
    href: "/lessons/deepfakes",
    duration: "18 min",
    difficulty: "Advanced",
    color: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
    topics: ["What are deepfakes", "Spotting fakes", "Reverse image search", "Media literacy"],
  },
  {
    title: "Privacy Protection",
    description: "Control your personal information and understand how your data is collected and used",
    icon: Shield,
    href: "/lessons/privacy",
    duration: "20 min",
    difficulty: "Intermediate",
    color: "bg-green-500/10 text-green-600 dark:text-green-400",
    topics: ["Privacy settings", "Data collection", "Location tracking", "App permissions"],
  },
  {
    title: "Social Media Safety",
    description: "Navigate social platforms safely and manage your online presence responsibly",
    icon: Users,
    href: "/lessons/social-media",
    duration: "18 min",
    difficulty: "Beginner",
    color: "bg-pink-500/10 text-pink-600 dark:text-pink-400",
    topics: ["Privacy settings", "Stranger danger", "Oversharing", "Platform-specific tips"],
  },
  {
    title: "Cyberbullying",
    description: "Understand, prevent, and respond to online harassment and bullying",
    icon: Heart,
    href: "/lessons/cyberbullying",
    duration: "15 min",
    difficulty: "Beginner",
    color: "bg-orange-500/10 text-orange-600 dark:text-orange-400",
    topics: ["Recognizing bullying", "How to respond", "Being an ally", "Getting help"],
  },
  {
    title: "Malware & Viruses",
    description: "Protect your devices from malicious software, viruses, and digital threats",
    icon: Bug,
    href: "/lessons/malware",
    duration: "20 min",
    difficulty: "Intermediate",
    color: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
    topics: ["Types of malware", "Safe downloads", "Antivirus software", "Device protection"],
  },
  {
    title: "Gaming Safety",
    description: "Stay safe while gaming online, protect your accounts, and avoid gaming scams",
    icon: Gamepad2,
    href: "/lessons/gaming-safety",
    duration: "18 min",
    difficulty: "Beginner",
    color: "bg-cyan-500/10 text-cyan-600 dark:text-cyan-400",
    topics: ["Account protection", "Gaming scams", "In-game chat safety", "Healthy gaming"],
  },
  {
    title: "Digital Footprint",
    description: "Understand how your online activities create a permanent record",
    icon: Footprints,
    href: "/lessons/digital-footprint",
    duration: "18 min",
    difficulty: "Intermediate",
    color: "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400",
    topics: ["What is a footprint", "Managing your reputation", "Future impact", "Cleaning up"],
  },
  {
    title: "WiFi & Network Security",
    description: "Stay safe on public WiFi and protect your home network",
    icon: Wifi,
    href: "/lessons/wifi-security",
    duration: "15 min",
    difficulty: "Intermediate",
    color: "bg-teal-500/10 text-teal-600 dark:text-teal-400",
    topics: ["Public WiFi risks", "VPNs", "Home network security", "HTTPS"],
  },
]

export default function LessonsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 px-4 bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center max-w-3xl mx-auto">
              <Badge variant="secondary" className="mb-4">
                <BookOpen className="h-3 w-3 mr-1" />
                Learning Modules
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
                Digital Security Lessons
              </h1>
              <p className="text-lg text-muted-foreground text-pretty">
                Comprehensive lessons designed for students ages 10-18. Each lesson includes 
                real-world examples, practical tips, and interactive quizzes.
              </p>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-8 px-4 border-b border-border">
          <div className="container mx-auto max-w-6xl">
            <div className="flex flex-wrap justify-center gap-8 md:gap-16">
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">10</p>
                <p className="text-sm text-muted-foreground">Lessons</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">3+</p>
                <p className="text-sm text-muted-foreground">Hours of Content</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">40+</p>
                <p className="text-sm text-muted-foreground">Topics Covered</p>
              </div>
            </div>
          </div>
        </section>

        {/* Lessons Grid */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="grid gap-6">
              {lessons.map((lesson, index) => (
                <Card key={lesson.title} className="group hover:shadow-lg transition-all duration-300 border-border overflow-hidden">
                  <div className="flex flex-col md:flex-row">
                    <div className={`w-full md:w-2 ${lesson.color.replace('/10', '')}`} />
                    <div className="flex-1 p-6">
                      <div className="flex flex-col lg:flex-row lg:items-center gap-6">
                        <div className={`w-14 h-14 rounded-xl ${lesson.color} flex items-center justify-center shrink-0`}>
                          <lesson.icon className="h-7 w-7" />
                        </div>
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <span className="text-sm text-muted-foreground font-medium">Lesson {index + 1}</span>
                            <Badge variant={lesson.difficulty === "Beginner" ? "secondary" : lesson.difficulty === "Intermediate" ? "outline" : "default"}>
                              {lesson.difficulty}
                            </Badge>
                            <span className="text-sm text-muted-foreground flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {lesson.duration}
                            </span>
                          </div>
                          <h2 className="text-xl font-bold mb-2">{lesson.title}</h2>
                          <p className="text-muted-foreground mb-4">{lesson.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {lesson.topics.map((topic) => (
                              <Badge key={topic} variant="secondary" className="text-xs">
                                {topic}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <Button asChild className="shrink-0">
                          <Link href={lesson.href}>
                            Start Lesson
                            <ChevronRight className="h-4 w-4 ml-1" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 px-4 bg-muted/50">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to Test Your Knowledge?</h2>
            <p className="text-muted-foreground mb-8">
              After completing lessons, take our interactive quizzes to reinforce what you have learned.
            </p>
            <Button asChild size="lg">
              <Link href="/quizzes">Take a Quiz</Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
