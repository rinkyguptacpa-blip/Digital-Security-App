import { Users } from 'lucide-react'
import { LessonPage } from '@/components/lesson-page'
import { ContentCard, ExampleBox, QuickFact, StepList } from '@/components/lesson-content'

const sections = [
  {
    id: 'social-media-landscape',
    title: 'Understanding Social Media',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Social media platforms like Instagram, TikTok, Snapchat, Discord, and YouTube are 
          where most young people spend their digital time. These platforms can be great for 
          connecting with friends, expressing creativity, and learning new things, but they 
          also come with real risks.
        </p>
        
        <ContentCard type="info" title="Why Social Media Needs Special Attention">
          <p>
            Social media is designed to keep you engaged. Features like infinite scroll, 
            notifications, and algorithmic feeds are specifically engineered to maximize the 
            time you spend on the platform. Understanding this helps you use social media more 
            intentionally rather than mindlessly.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Average Daily Social Media Use by Teens</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Average teen: 4.8 hours per day on social media</li>
          <li>Many teens check their phones 100+ times daily</li>
          <li>1 in 3 teens say they use social media &quot;almost constantly&quot;</li>
        </ul>

        <QuickFact>
          Social media platforms employ thousands of engineers whose job is to make their apps 
          as addictive as possible. Knowing this helps you be more aware of how these platforms 
          influence your behavior.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'account-security',
    title: 'Securing Your Social Media Accounts',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Your social media accounts are valuable targets for hackers. Here is how to lock 
          them down:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Essential Security Steps</h3>
        <StepList
          steps={[
            'Use a unique, strong password for each social media account',
            'Enable two-factor authentication on every platform',
            'Set up login alerts to be notified of new device logins',
            'Review active sessions and remove devices you do not recognize',
            'Keep your recovery email and phone number up to date',
            'Never share verification codes with anyone, even "support"',
          ]}
        />

        <ContentCard type="warning" title="Common Ways Accounts Get Hacked">
          <ul className="space-y-1 mt-2">
            <li>Clicking on phishing links in DMs claiming &quot;is this you in this video?&quot;</li>
            <li>Using the same password as a site that was breached</li>
            <li>Sharing passwords with &quot;friends&quot; who later become ex-friends</li>
            <li>Falling for fake &quot;verification&quot; or &quot;support&quot; messages</li>
            <li>Using fake third-party apps that promise followers or features</li>
          </ul>
        </ContentCard>

        <ExampleBox title="Red Flags That Your Account May Be Compromised" good={false}>
          <ul className="space-y-1 mt-2">
            <li>Posts or messages you did not create</li>
            <li>Friends saying they received weird DMs from you</li>
            <li>Login alerts from locations you were not in</li>
            <li>Changed profile information or email</li>
            <li>New followers or following accounts you did not add</li>
          </ul>
        </ExampleBox>
      </>
    ),
  },
  {
    id: 'privacy-settings',
    title: 'Privacy Settings That Matter',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Every social media platform has privacy settings that control who can see your 
          content and interact with you. Here is what to configure:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Key Privacy Settings</h3>
        
        <ExampleBox title="Account Visibility">
          <p>
            <strong>Private Account:</strong> Only approved followers can see your posts. 
            Recommended for most users, especially those under 18.
          </p>
          <p className="mt-2">
            <strong>Public Account:</strong> Anyone can see your posts. Only choose this if 
            you understand the implications and have a specific reason.
          </p>
        </ExampleBox>

        <ExampleBox title="Interaction Controls">
          <ul className="space-y-1 mt-2">
            <li><strong>Who can DM you:</strong> Limit to followers or people you follow</li>
            <li><strong>Who can comment:</strong> Control or filter comments on your posts</li>
            <li><strong>Who can tag you:</strong> Require approval before tags show on your profile</li>
            <li><strong>Who can mention you:</strong> Limit who can @ mention you</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Discoverability">
          <ul className="space-y-1 mt-2">
            <li>Disable appearing in search engine results</li>
            <li>Turn off &quot;Suggested Users&quot; or &quot;Quick Add&quot; features</li>
            <li>Disable contact syncing (prevents the app from suggesting you to contacts)</li>
            <li>Turn off location-based suggestions</li>
          </ul>
        </ExampleBox>

        <ContentCard type="success" title="Platform-Specific Privacy Guides">
          <p className="mb-2"><strong>Instagram:</strong> Settings → Privacy → Set Private Account, control Story sharing</p>
          <p className="mb-2"><strong>TikTok:</strong> Settings → Privacy → Private Account, disable Suggest account, control Duets/Stitch</p>
          <p className="mb-2"><strong>Snapchat:</strong> Settings → Privacy → Ghost Mode on map, Contact Me settings</p>
          <p><strong>Discord:</strong> Privacy Settings → Disable DMs from server members, control friend requests</p>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'strangers-online',
    title: 'Interacting with Strangers',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          One of the biggest risks on social media is people who are not who they claim to be. 
          Here is how to stay safe when encountering strangers online:
        </p>

        <ContentCard type="danger" title="Catfishing">
          <p>
            Catfishing is when someone creates a fake online identity to deceive others. They 
            might use stolen photos, fake names, and completely fabricated stories. Catfishers 
            can be scammers, predators, or people with malicious intent.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Red Flags for Fake Profiles</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Profile is new with few posts or followers</li>
          <li>Photos look like professional models or stock images</li>
          <li>They claim to live nearby but have never heard of local places</li>
          <li>Stories are inconsistent or do not add up over time</li>
          <li>They refuse to video chat or always have an excuse</li>
          <li>They ask for personal information or favors quickly</li>
          <li>They try to move conversations off the platform to texting</li>
        </ul>

        <ContentCard type="warning" title="Grooming Warning Signs">
          <p>
            Adults who target young people online often use a process called &quot;grooming&quot; - 
            building trust over time before making inappropriate requests. Warning signs include:
          </p>
          <ul className="space-y-1 mt-2">
            <li>Giving excessive compliments and attention</li>
            <li>Asking you to keep the relationship secret</li>
            <li>Sending gifts or money</li>
            <li>Gradually pushing boundaries and making inappropriate comments</li>
            <li>Trying to isolate you from friends and family</li>
            <li>Making you feel special or &quot;mature for your age&quot;</li>
          </ul>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Safe Practices</h3>
        <StepList
          steps={[
            'Never share personal information with people you only know online',
            'Do not accept friend/follow requests from people you do not know in real life',
            'Never agree to meet someone you met online without a parent present',
            'If someone makes you uncomfortable, block them and tell a trusted adult',
            'Trust your instincts - if something feels wrong, it probably is',
          ]}
        />
      </>
    ),
  },
  {
    id: 'content-sharing',
    title: 'Smart Content Sharing',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Everything you post online creates a permanent record. Here is how to share 
          responsibly:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Before You Post, Ask Yourself</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Would I be okay with my parents seeing this?</li>
          <li>Would I be embarrassed if this was shown at a job interview in 10 years?</li>
          <li>Could this hurt someone&apos;s feelings or reputation?</li>
          <li>Am I sharing this to make myself feel better or to tear someone else down?</li>
          <li>Does this reveal private information about me or others?</li>
        </ul>

        <ContentCard type="danger" title="Things That Should Never Be Posted">
          <ul className="space-y-1 mt-2">
            <li>Illegal activities, even as a &quot;joke&quot;</li>
            <li>Anything that could be considered harassment or bullying</li>
            <li>Private photos or information about others without their consent</li>
            <li>Content that sexualizes yourself or others</li>
            <li>Detailed personal information like address, phone number, or schedule</li>
            <li>Photos of IDs, tickets, or documents with personal info</li>
          </ul>
        </ContentCard>

        <ExampleBox title="The Screenshot Test">
          <p>
            Before posting anything, imagine it being screenshot and shared by someone who 
            does not like you, or sent to your principal, parents, or future college admissions 
            officer. If that thought makes you uncomfortable, do not post it.
          </p>
        </ExampleBox>

        <QuickFact>
          A single inappropriate post has resulted in students losing college admissions, 
          scholarships, and job offers. Think before you post - the internet never forgets.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'photo-safety',
    title: 'Photo and Video Safety',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Photos and videos reveal more than you might think. Here is how to share visual 
          content safely:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">What Photos Can Reveal</h3>
        
        <ExampleBox title="Hidden Information in Photos" good={false}>
          <ul className="space-y-1 mt-2">
            <li><strong>Location:</strong> GPS coordinates embedded in the file, visible landmarks</li>
            <li><strong>Identity:</strong> School uniforms, sports jerseys with your name</li>
            <li><strong>Address:</strong> House numbers, street signs, distinctive features</li>
            <li><strong>Schedule:</strong> Regular posting times reveal your routine</li>
            <li><strong>Valuables:</strong> Expensive items in the background</li>
          </ul>
        </ExampleBox>

        <h3 className="text-lg font-semibold mt-6 mb-3">Photo Sharing Best Practices</h3>
        <StepList
          steps={[
            'Turn off location tagging in your camera and social media apps',
            'Check backgrounds for identifying information before posting',
            'Avoid posting photos in school uniforms with visible school names',
            'Wait until you are back home to post vacation photos',
            'Be careful with mirror selfies that might show your room details',
            'Ask permission before posting photos of others',
          ]}
        />

        <ContentCard type="warning" title="Once Sent, Never Unsent">
          <p>
            Even &quot;disappearing&quot; content on Snapchat or Instagram Stories can be screenshot. 
            Once you send a photo to someone else, you lose control of it forever. Never send 
            photos you would not want to become public.
          </p>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'toxic-content',
    title: 'Dealing with Toxic Content',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Social media can expose you to content that is harmful, disturbing, or designed to 
          make you feel bad. Here is how to protect your mental health:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Types of Toxic Content</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li><strong>Comparison content:</strong> Posts that make you feel inadequate</li>
          <li><strong>Hate speech:</strong> Content targeting groups or individuals</li>
          <li><strong>Misinformation:</strong> False or misleading content</li>
          <li><strong>Violent or disturbing imagery:</strong> Content meant to shock</li>
          <li><strong>Pro-harmful behaviors:</strong> Content promoting eating disorders, self-harm, etc.</li>
        </ul>

        <ContentCard type="success" title="Curating Your Feed">
          <p>
            You have control over what you see. Use these tools:
          </p>
          <ul className="space-y-1 mt-2">
            <li><strong>Mute/Block:</strong> Remove accounts that make you feel bad</li>
            <li><strong>Not Interested:</strong> Tell the algorithm what you do not want to see</li>
            <li><strong>Unfollow:</strong> It is okay to unfollow even friends if their content affects you</li>
            <li><strong>Sensitive Content Controls:</strong> Most platforms let you filter sensitive content</li>
          </ul>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Signs Social Media Is Affecting Your Mental Health</h3>
        <ExampleBox title="Warning Signs" good={false}>
          <ul className="space-y-1 mt-2">
            <li>Feeling worse about yourself after scrolling</li>
            <li>Constantly comparing yourself to others online</li>
            <li>Anxiety about likes, comments, or followers</li>
            <li>Checking your phone first thing in the morning and last at night</li>
            <li>Feeling anxious when you cannot check social media</li>
            <li>Losing sleep to scroll through feeds</li>
          </ul>
        </ExampleBox>

        <QuickFact>
          Studies show that limiting social media use to 30 minutes per day significantly 
          reduces depression and loneliness. Consider setting app time limits on your phone.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'digital-wellbeing',
    title: 'Digital Wellbeing and Balance',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Using social media in a healthy way means finding balance. Here are strategies to 
          keep your digital life positive:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Healthy Social Media Habits</h3>
        <StepList
          steps={[
            'Set specific times for checking social media instead of all day',
            'Turn off non-essential notifications',
            'Keep your phone out of your bedroom at night',
            'Take regular breaks - try a social media detox weekend',
            'Follow accounts that inspire and educate, not just entertain',
            'Engage meaningfully instead of just passive scrolling',
            'Do not check social media in the first hour after waking',
          ]}
        />

        <ContentCard type="success" title="Built-in Tools to Help">
          <ul className="space-y-1 mt-2">
            <li><strong>Screen Time (iOS) / Digital Wellbeing (Android):</strong> See how much time you spend and set limits</li>
            <li><strong>App Timers:</strong> Set daily limits for specific apps</li>
            <li><strong>Focus/Do Not Disturb Modes:</strong> Block notifications during certain times</li>
            <li><strong>Grayscale Mode:</strong> Making your screen black and white reduces appeal</li>
          </ul>
        </ContentCard>

        <ExampleBox title="The 3-2-1 Rule">
          <p>
            <strong>3</strong> hours before bed: No more food<br />
            <strong>2</strong> hours before bed: No more work/homework<br />
            <strong>1</strong> hour before bed: No more screens (including social media)
          </p>
          <p className="mt-2">This routine significantly improves sleep quality and mental health.</p>
        </ExampleBox>

        <ContentCard type="info" title="Remember">
          <p>
            Social media shows everyone&apos;s highlight reel, not their real life. People only post 
            their best moments, most flattering photos, and biggest achievements. No one&apos;s life 
            is actually as perfect as their Instagram makes it seem. Compare yourself to your 
            past self, not to others&apos; curated online presence.
          </p>
        </ContentCard>
      </>
    ),
  },
]

export default function SocialMediaLesson() {
  return (
    <LessonPage
      title="Social Media Safety"
      description="Learn to navigate social media platforms safely, protect your accounts, manage your online presence, and maintain digital wellbeing."
      icon={Users}
      duration="25 min read"
      difficulty="Beginner"
      sections={sections}
      prevLesson={{ href: '/lessons/privacy', title: 'Privacy' }}
      nextLesson={{ href: '/lessons/cyberbullying', title: 'Cyberbullying' }}
      quizHref="/quizzes/social-media"
    />
  )
}
