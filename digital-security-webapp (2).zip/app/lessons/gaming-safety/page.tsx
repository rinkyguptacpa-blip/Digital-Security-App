import { LessonPage } from "@/components/lesson-page"
import {
  Section,
  Paragraph,
  BulletList,
  NumberedList,
  WarningBox,
  TipBox,
  ExampleBox,
  QuizQuestion,
} from "@/components/lesson-content"

export const metadata = {
  title: "Gaming Safety | CyberSafe Academy",
  description: "Learn how to stay safe while gaming online, avoid scams, protect your accounts, and have fun responsibly.",
}

export default function GamingSafetyPage() {
  return (
    <LessonPage
      title="Gaming Safety"
      description="Stay safe and have fun while gaming online"
      duration="18 min"
      difficulty="Beginner"
      prevLesson={{ href: "/lessons/malware", title: "Malware & Viruses" }}
      nextLesson={{ href: "/lessons/digital-footprint", title: "Digital Footprint" }}
    >
      <Section title="Why Gaming Safety Matters">
        <Paragraph>
          Online gaming is awesome - you can play with friends, meet new people from around the world, and have amazing adventures. But just like in the real world, there are some people online who try to take advantage of gamers. Understanding gaming safety helps you enjoy your favorite games while protecting yourself and your accounts.
        </Paragraph>
        <Paragraph>
          Whether you play Minecraft, Fortnite, Roblox, League of Legends, or any other game, the same safety principles apply. Let&apos;s learn how to game smart!
        </Paragraph>
      </Section>

      <Section title="Protecting Your Gaming Accounts">
        <Paragraph>
          Your gaming account might have rare skins, high levels, in-game currency, or items you have worked hard to earn. Here is how to keep them safe:
        </Paragraph>

        <BulletList
          items={[
            "Use a strong, unique password for each gaming account - not the same as your email or other accounts",
            "Enable two-factor authentication (2FA) whenever available - this is the best protection against hackers",
            "Never share your login information with anyone, even close friends",
            "Be suspicious of anyone asking for your account details for any reason",
            "Link your account to your email so you can recover it if needed",
            "Log out of your account on shared or public computers",
            "Check your account activity regularly for unauthorized logins",
          ]}
        />

        <ExampleBox title="The 'Account Sharing' Trap">
          &quot;Hey, let me borrow your account to check out that skin!&quot; Even if a friend asks to use your account, saying no is okay. Account sharing violates most games&apos; terms of service and can result in permanent bans. Plus, once someone has your password, you cannot control what they do with it.
        </ExampleBox>
      </Section>

      <Section title="Common Gaming Scams to Avoid">
        <Paragraph>
          Scammers target gamers because they know you value your accounts and items. Here are the most common scams:
        </Paragraph>

        <NumberedList
          items={[
            "Free V-Bucks/Robux generators: Websites or videos promising free in-game currency are always scams. They steal your login information or install malware.",
            "Phishing websites: Fake login pages that look exactly like the real game website but steal your password when you enter it.",
            "Item duplication scams: Someone claims they can duplicate your rare items. They just take your items and disappear.",
            "Account upgrade scams: Offers to upgrade your account, give you admin powers, or unlock premium features for free.",
            "Trading scams: Someone offers an amazing trade, but the item is fake, or they switch items at the last second.",
            "Fake giveaways: 'You won a rare skin! Click here to claim!' - These are designed to steal your account.",
            "Impersonation: Scammers pretending to be game moderators, YouTubers, or streamers asking for your information.",
          ]}
        />

        <WarningBox title="If It Sounds Too Good to Be True...">
          There is no such thing as free V-Bucks generators, Robux hacks, or unlimited coins. Every single one of these is a scam designed to steal your account or install malware. The only way to get in-game currency is through the official game or store.
        </WarningBox>
      </Section>

      <Section title="Safe Communication in Games">
        <Paragraph>
          Many games let you chat with other players. Here is how to communicate safely:
        </Paragraph>

        <BulletList
          items={[
            "Never share personal information: real name, age, school, address, or phone number",
            "Use your game username, not your real name",
            "Be careful about joining voice chats with strangers",
            "If someone makes you uncomfortable, mute, block, and report them",
            "Do not share photos of yourself with people you meet in games",
            "Remember that people online might not be who they claim to be",
            "Keep conversations about the game - do not share personal details",
            "Trust your instincts - if something feels wrong, it probably is",
          ]}
        />

        <ExampleBox title="The 'Older Friend' Warning Sign">
          An adult who wants to be close friends with young gamers and asks personal questions is a red flag. Real gaming friends talk about the game, strategies, and having fun - they do not need to know where you live or go to school. If someone is overly interested in your personal life, tell a trusted adult.
        </ExampleBox>
      </Section>

      <Section title="In-Game Purchases: Being Smart with Money">
        <Paragraph>
          Many games have in-app purchases for skins, characters, or currency. Here is how to handle them wisely:
        </Paragraph>

        <BulletList
          items={[
            "Always ask permission before making any purchase",
            "Set up purchase passwords or parental controls to prevent accidental spending",
            "Remember that skins and items are just cosmetic - they do not make you better at the game",
            "Be aware of 'loot boxes' and randomized purchases - you might not get what you want",
            "Set a budget and stick to it - it is easy to overspend on small purchases that add up",
            "Never buy in-game currency from third-party websites - only use official stores",
            "Watch out for 'limited time' pressure tactics designed to make you buy quickly",
          ]}
        />

        <TipBox title="The $5 Test">
          Before buying something in a game, ask yourself: &quot;Will I still care about this item in a month?&quot; Often, that skin you desperately want today will be forgotten next week. Waiting a day or two before purchasing helps you make better decisions.
        </TipBox>
      </Section>

      <Section title="Dealing with Toxic Players">
        <Paragraph>
          Unfortunately, some players are rude, mean, or try to ruin the game for others. Here is how to handle them:
        </Paragraph>

        <NumberedList
          items={[
            "Do not engage: Responding to toxic players often makes things worse. Do not argue back.",
            "Use mute and block features: Most games let you mute chat or block specific players.",
            "Report bad behavior: Use the game's reporting system. Reports help keep the community safe.",
            "Take breaks: If you are getting frustrated or upset, step away from the game for a while.",
            "Play with friends: Gaming with people you know and trust is usually more fun and safer.",
            "Remember it is just a game: Winning and losing are part of gaming. Do not let it affect your real mood.",
            "Do not become toxic yourself: Treat others how you want to be treated, even in competitive games.",
          ]}
        />

        <ExampleBox title="When to Walk Away">
          If a game session is making you angry, stressed, or upset, it is time to take a break. Close the game, do something else for a while, and come back when you are feeling better. No game is worth ruining your mood or your day.
        </ExampleBox>
      </Section>

      <Section title="Streaming and Content Creation Safety">
        <Paragraph>
          Many young people stream on Twitch or YouTube or create gaming content. If you do this, keep these safety tips in mind:
        </Paragraph>

        <BulletList
          items={[
            "Never show personal information on stream (mail, documents, background details)",
            "Use a separate email for your streaming accounts",
            "Be careful about showing your location through windows or recognizable landmarks",
            "Consider using a screen name different from your real name",
            "Moderate your chat and have clear rules about acceptable behavior",
            "Be careful about accepting gifts, donations, or offers from viewers",
            "Do not feel pressured to share personal details with your audience",
            "Have a trusted adult aware of your streaming activities",
          ]}
        />

        <WarningBox title="Doxxing Danger">
          &quot;Doxxing&quot; is when someone finds and shares your personal information online without permission. Streamers are common targets. Be very careful about what you show on screen - even a glimpse of mail, a school logo, or a recognizable location can give away personal information.
        </WarningBox>
      </Section>

      <Section title="Healthy Gaming Habits">
        <Paragraph>
          Gaming is great, but balance is important for your health and well-being:
        </Paragraph>

        <BulletList
          items={[
            "Take regular breaks - follow the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds",
            "Set time limits and stick to them",
            "Do not skip meals, sleep, or homework for gaming",
            "Stay physically active - balance screen time with outdoor time",
            "Keep gaming in shared spaces where adults can be aware of what is happening",
            "Maintain real-world friendships alongside online ones",
            "If gaming is affecting your mood, grades, or relationships, it is time to reassess",
          ]}
        />

        <TipBox title="Gaming Addiction Warning Signs">
          If you find yourself unable to stop playing, lying about how much you game, losing interest in other activities, or feeling anxious when you cannot play, these might be signs of gaming addiction. Talk to a trusted adult if you are concerned about your gaming habits.
        </TipBox>
      </Section>

      <Section title="What to Do If Something Goes Wrong">
        <Paragraph>
          If you experience any of these situations, take action:
        </Paragraph>

        <NumberedList
          items={[
            "Account hacked: Change your password immediately (from a clean device), enable 2FA, contact game support, and check linked accounts.",
            "Scammed out of items: Report the scammer, contact game support with evidence, and warn others if possible.",
            "Someone being inappropriate: Block them, report them, save evidence (screenshots), and tell a trusted adult.",
            "Bullied or harassed: Mute/block the person, report them, take a break, and talk to someone about how you feel.",
            "Made an accidental purchase: Contact game support quickly - many will refund accidental purchases.",
            "Downloaded something suspicious: Disconnect from the internet, tell an adult, and run antivirus software.",
          ]}
        />
      </Section>

      <Section title="Test Your Knowledge">
        <QuizQuestion
          question="A website claims to give you 10,000 free V-Bucks if you enter your Fortnite login. What should you do?"
          options={[
            "Enter your login - free V-Bucks are awesome!",
            "Share the website with friends so they can get free V-Bucks too",
            "Ignore the website - this is a scam to steal your account",
            "Use a fake password to see if it works first",
          ]}
          correctIndex={2}
          explanation="Free V-Bucks generators do not exist. Every single one is a scam designed to steal your account information. The only way to get V-Bucks is through the official Fortnite store."
        />

        <QuizQuestion
          question="Someone you met in a game wants to become close friends and keeps asking where you live and go to school. What should you do?"
          options={[
            "Tell them - they seem nice and you want to be friends",
            "Give them fake information so they stop asking",
            "Stop sharing personal information, and if they persist, block and report them",
            "Ask for their information first to make sure it is fair",
          ]}
          correctIndex={2}
          explanation="Real gaming friends do not need to know your personal details. Someone persistently asking for this information is a red flag. Stop sharing, and if they continue, block and report them."
        />

        <QuizQuestion
          question="Your gaming friend asks to borrow your account 'just for a few minutes' to try a skin. What should you do?"
          options={[
            "Let them - friends share with each other",
            "Politely decline - account sharing is risky and against most games' rules",
            "Only if they share their account password first",
            "Give them temporary access by changing your password after",
          ]}
          correctIndex={1}
          explanation="Never share your account with anyone. Account sharing violates most games' terms of service, can result in bans, and puts your account at risk. It is okay to say no, even to friends."
        />
      </Section>

      <Section title="Key Takeaways">
        <BulletList
          items={[
            "Protect your gaming accounts with strong passwords and two-factor authentication",
            "Free currency generators and item duplication offers are always scams",
            "Never share personal information with people you meet in games",
            "Use mute, block, and report features to handle toxic players",
            "Be smart about in-game purchases - set budgets and avoid impulse buying",
            "If streaming, be careful not to reveal personal information on camera",
            "Maintain healthy gaming habits with breaks, time limits, and balance",
            "If something goes wrong, tell a trusted adult and use official support channels",
          ]}
        />
      </Section>
    </LessonPage>
  )
}
