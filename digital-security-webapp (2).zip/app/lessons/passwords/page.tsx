import { Lock } from 'lucide-react'
import { LessonPage } from '@/components/lesson-page'
import { ContentCard, ExampleBox, QuickFact, StepList } from '@/components/lesson-content'

const sections = [
  {
    id: 'why-passwords-matter',
    title: 'Why Passwords Matter',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Think of a password like a key to your house. Would you give that key to just anyone? 
          Would you use a key that&apos;s easy to copy? Your online accounts contain personal 
          information, photos, messages, and sometimes even access to your money. A strong 
          password is your first line of defense against hackers and identity thieves.
        </p>
        
        <ContentCard type="warning" title="Real-World Impact">
          <p>
            In 2023, over 4.1 billion records were exposed in data breaches worldwide. Many of 
            these breaches happened because people used weak passwords that hackers could easily 
            guess. Young people are often targeted because they may have less experience with 
            online security.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">What Hackers Can Do With Your Password</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Access your social media and post embarrassing content</li>
          <li>Read your private messages and photos</li>
          <li>Steal your gaming accounts and virtual items</li>
          <li>Use your accounts to scam your friends and family</li>
          <li>Access your email and reset passwords for other accounts</li>
          <li>Steal money from connected payment methods</li>
        </ul>
      </>
    ),
  },
  {
    id: 'weak-vs-strong',
    title: 'Weak vs. Strong Passwords',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Not all passwords are created equal. Let&apos;s look at what makes a password weak or strong, 
          and why it matters.
        </p>

        <ExampleBox title="Weak Passwords - Easy to Guess" good={false}>
          <ul className="space-y-1 mt-2">
            <li><code className="bg-secondary px-2 py-1 rounded">password123</code> - Too common and predictable</li>
            <li><code className="bg-secondary px-2 py-1 rounded">john2010</code> - Name + birth year is easy to find</li>
            <li><code className="bg-secondary px-2 py-1 rounded">iloveyou</code> - One of the most common passwords</li>
            <li><code className="bg-secondary px-2 py-1 rounded">123456789</code> - Sequential numbers are cracked instantly</li>
            <li><code className="bg-secondary px-2 py-1 rounded">qwerty</code> - Keyboard patterns are well-known</li>
            <li><code className="bg-secondary px-2 py-1 rounded">football</code> - Common words are in hacker dictionaries</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Strong Passwords - Hard to Crack" good={true}>
          <ul className="space-y-1 mt-2">
            <li><code className="bg-secondary px-2 py-1 rounded">Tr0ub4dor&3#Pizza</code> - Mix of characters with a memorable twist</li>
            <li><code className="bg-secondary px-2 py-1 rounded">MyD0g$parkY!Runs2Fast</code> - Passphrase with substitutions</li>
            <li><code className="bg-secondary px-2 py-1 rounded">7&amp;Kj#mN9$pL@2xQ</code> - Random characters (use a password manager)</li>
          </ul>
        </ExampleBox>

        <ContentCard type="info" title="How Fast Can Hackers Crack Passwords?">
          <ul className="space-y-1 mt-2">
            <li><strong>6 characters, lowercase only:</strong> Instant</li>
            <li><strong>8 characters, lowercase only:</strong> About 5 minutes</li>
            <li><strong>8 characters, mixed case + numbers:</strong> About 1 hour</li>
            <li><strong>12 characters, mixed case + numbers + symbols:</strong> 34,000 years</li>
            <li><strong>16 characters, all character types:</strong> Billions of years</li>
          </ul>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'creating-strong-passwords',
    title: 'Creating Strong Passwords',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Here are the key rules for creating passwords that are both strong and memorable:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">The Golden Rules</h3>
        <StepList
          steps={[
            'Make it at least 12 characters long - longer is always better',
            'Use a mix of uppercase letters, lowercase letters, numbers, and symbols',
            'Avoid personal information like names, birthdays, or pet names',
            'Never use the same password for multiple accounts',
            'Avoid common words or patterns that appear in dictionaries',
          ]}
        />

        <h3 className="text-lg font-semibold mt-6 mb-3">The Passphrase Method</h3>
        <p className="text-muted-foreground mb-4">
          One of the best ways to create a strong, memorable password is to use a passphrase. 
          This is a series of random words that you can easily picture in your mind.
        </p>

        <ExampleBox title="Creating a Passphrase">
          <ol className="space-y-2 mt-2">
            <li><strong>1. Pick 4-5 random words:</strong> purple elephant dancing pizza cloud</li>
            <li><strong>2. Make it unique:</strong> Add numbers and symbols: Purple3Elephant$Dancing!Pizza@Cloud</li>
            <li><strong>3. Create a mental image:</strong> Picture a purple elephant dancing while eating pizza in the clouds</li>
          </ol>
        </ExampleBox>

        <QuickFact>
          A passphrase like &quot;CorrectHorseBatteryStaple&quot; is much stronger than a complex but 
          short password like &quot;Tr0ub4dor&amp;3&quot; because length matters more than complexity.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'password-managers',
    title: 'Password Managers',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Since you need a unique, strong password for every account, remembering them all is 
          nearly impossible. That&apos;s where password managers come in.
        </p>

        <ContentCard type="success" title="What is a Password Manager?">
          <p>
            A password manager is like a secure digital vault that stores all your passwords. 
            You only need to remember one master password to access the vault. The password 
            manager can also generate super-strong random passwords for you.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Popular Password Managers for Students</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li><strong>Bitwarden</strong> - Free and open source, works on all devices</li>
          <li><strong>1Password</strong> - Great family plans, easy to use</li>
          <li><strong>Apple Keychain</strong> - Built into Apple devices, free</li>
          <li><strong>Google Password Manager</strong> - Built into Chrome, free</li>
        </ul>

        <h3 className="text-lg font-semibold mt-6 mb-3">How to Use a Password Manager</h3>
        <StepList
          steps={[
            'Download and install a password manager app',
            'Create one very strong master password (use the passphrase method!)',
            'Add your existing accounts and passwords',
            'Let the manager generate new, strong passwords when you change them',
            'Use the browser extension to auto-fill passwords',
          ]}
        />

        <ContentCard type="warning" title="Important Warning">
          <p>
            Your master password for the password manager is the most important password you 
            have. Make it extremely strong and NEVER share it with anyone. If someone gets 
            this password, they have access to ALL your accounts.
          </p>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'two-factor-authentication',
    title: 'Two-Factor Authentication (2FA)',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Even the strongest password can be stolen in a data breach. Two-factor authentication 
          (2FA) adds a second layer of protection, so even if someone knows your password, they 
          still cannot access your account.
        </p>

        <ContentCard type="info" title="How 2FA Works">
          <p>
            Think of 2FA like a two-lock door. The first lock is your password (something you know). 
            The second lock is usually your phone (something you have). To get in, you need both.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Types of 2FA</h3>
        
        <ExampleBox title="SMS/Text Message Codes">
          <p>A code is sent to your phone via text message. This is better than nothing, but 
          not the most secure option because phone numbers can be hijacked.</p>
        </ExampleBox>

        <ExampleBox title="Authenticator Apps (Recommended)" good={true}>
          <p>Apps like Google Authenticator, Authy, or Microsoft Authenticator generate codes 
          that change every 30 seconds. These are much more secure than SMS.</p>
        </ExampleBox>

        <ExampleBox title="Hardware Security Keys (Most Secure)" good={true}>
          <p>Physical devices like YubiKey that you plug into your computer or tap to your phone. 
          These are the gold standard for security but cost money.</p>
        </ExampleBox>

        <h3 className="text-lg font-semibold mt-6 mb-3">Setting Up 2FA</h3>
        <StepList
          steps={[
            'Download an authenticator app (Google Authenticator or Authy)',
            'Go to your account settings and find "Security" or "Two-Factor Authentication"',
            'Choose "Authenticator App" as your 2FA method',
            'Scan the QR code shown on screen with your authenticator app',
            'Enter the 6-digit code to confirm setup',
            'Save your backup codes in a safe place (in case you lose your phone)',
          ]}
        />

        <ContentCard type="success" title="Accounts You Should Protect with 2FA">
          <ul className="space-y-1 mt-2">
            <li>Email accounts (most important - used to reset other passwords)</li>
            <li>Social media (Instagram, TikTok, Snapchat, Discord)</li>
            <li>Gaming platforms (Steam, Xbox, PlayStation, Epic Games)</li>
            <li>School accounts</li>
            <li>Any account with payment information</li>
          </ul>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'common-mistakes',
    title: 'Common Password Mistakes to Avoid',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Even people who know better sometimes make these common mistakes. Make sure you are not 
          falling into these traps:
        </p>

        <ExampleBox title="Reusing Passwords" good={false}>
          <p>
            <strong>The Problem:</strong> If you use the same password for your email, Instagram, 
            and gaming accounts, a hacker only needs to crack one to get into all of them.
          </p>
          <p className="mt-2">
            <strong>Real Example:</strong> In 2016, a LinkedIn data breach exposed millions of 
            passwords. Hackers used those same email/password combinations to break into people&apos;s 
            Netflix, Twitter, and other accounts.
          </p>
        </ExampleBox>

        <ExampleBox title="Sharing Passwords with Friends" good={false}>
          <p>
            <strong>The Problem:</strong> Even your best friend might accidentally share your 
            password, or your friendship might change. Never share passwords, even for &quot;trusted&quot; 
            accounts like streaming services.
          </p>
        </ExampleBox>

        <ExampleBox title="Writing Passwords on Sticky Notes" good={false}>
          <p>
            <strong>The Problem:</strong> Anyone who sees your desk or computer can read your 
            passwords. This includes family members, friends, or anyone taking photos nearby.
          </p>
        </ExampleBox>

        <ExampleBox title="Using Public Computers Without Logging Out" good={false}>
          <p>
            <strong>The Problem:</strong> Library computers, school labs, and other public devices 
            might save your login information. The next person could access your accounts.
          </p>
          <p className="mt-2">
            <strong>Solution:</strong> Always use private/incognito mode on public computers and 
            make sure to log out of all accounts when you are done.
          </p>
        </ExampleBox>

        <ContentCard type="danger" title="Never Do These Things">
          <ul className="space-y-1 mt-2">
            <li>Send passwords through text messages or DMs</li>
            <li>Enter passwords on websites that do not show a lock icon (https://)</li>
            <li>Use password hints that reveal the actual password</li>
            <li>Save passwords in notes apps without encryption</li>
            <li>Trust websites that ask for your password via email</li>
          </ul>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'what-to-do-if-hacked',
    title: 'What To Do If Your Account Is Hacked',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          If you think someone has accessed your account without permission, act fast! Here is 
          your emergency action plan:
        </p>

        <ContentCard type="danger" title="Signs Your Account May Be Hacked">
          <ul className="space-y-1 mt-2">
            <li>You receive password reset emails you did not request</li>
            <li>Friends say they got strange messages from you</li>
            <li>You see posts or activity you did not do</li>
            <li>You cannot log in with your usual password</li>
            <li>You get alerts about logins from unfamiliar locations</li>
          </ul>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Emergency Action Steps</h3>
        <StepList
          steps={[
            'Change your password immediately (if you can still log in)',
            'Change the password for your email account first - this is used to reset other passwords',
            'Enable 2FA if you have not already',
            'Check for unfamiliar devices logged into your account and remove them',
            'Review recent activity and undo any unauthorized changes',
            'Warn your friends not to click on any suspicious messages from your account',
            'Report the hack to the platform using their official support channels',
            'If any payment info was involved, alert your parents and monitor for fraudulent charges',
          ]}
        />

        <ContentCard type="info" title="Telling a Trusted Adult">
          <p>
            If your account is hacked, it is always a good idea to tell a parent, guardian, or 
            teacher. They can help you secure your accounts and deal with any serious consequences 
            like identity theft or financial fraud.
          </p>
        </ContentCard>
      </>
    ),
  },
]

export default function PasswordsLesson() {
  return (
    <LessonPage
      title="Passwords & Two-Factor Authentication"
      description="Learn how to create unbreakable passwords and add extra layers of security to protect your online accounts from hackers."
      icon={Lock}
      duration="20 min read"
      difficulty="Beginner"
      sections={sections}
      nextLesson={{ href: '/lessons/phishing', title: 'Phishing & Scams' }}
      quizHref="/quizzes/passwords"
    />
  )
}
