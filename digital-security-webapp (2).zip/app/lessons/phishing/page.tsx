import { AlertTriangle } from 'lucide-react'
import { LessonPage } from '@/components/lesson-page'
import { ContentCard, ExampleBox, QuickFact, StepList } from '@/components/lesson-content'

const sections = [
  {
    id: 'what-is-phishing',
    title: 'What Is Phishing?',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Phishing is when scammers try to trick you into giving them your personal information, 
          passwords, or money by pretending to be someone you trust. The name comes from &quot;fishing&quot; 
          - attackers cast out bait hoping someone will bite.
        </p>
        
        <ContentCard type="warning" title="Why Phishing Works">
          <p>
            Phishing attacks work because they exploit our natural trust and emotions. Scammers 
            create a sense of urgency, fear, or excitement to make you act without thinking. 
            They might pretend to be your bank, a gaming company, or even a friend in trouble.
          </p>
        </ContentCard>

        <QuickFact>
          Over 3.4 billion phishing emails are sent every day worldwide. That is about 1% of all 
          emails! Young people are increasingly targeted because they spend more time online.
        </QuickFact>

        <h3 className="text-lg font-semibold mt-6 mb-3">Types of Phishing</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li><strong>Email Phishing:</strong> Fake emails that look like they are from real companies</li>
          <li><strong>Smishing:</strong> Phishing through SMS/text messages</li>
          <li><strong>Vishing:</strong> Phishing through voice calls</li>
          <li><strong>Social Media Phishing:</strong> Fake accounts or DMs on platforms like Instagram or Discord</li>
          <li><strong>Gaming Phishing:</strong> Fake offers for free V-Bucks, Robux, or other in-game currency</li>
        </ul>
      </>
    ),
  },
  {
    id: 'email-phishing',
    title: 'Recognizing Phishing Emails',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Phishing emails are designed to look legitimate, but there are always clues that 
          reveal they are fake. Here is what to look for:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Red Flags in Phishing Emails</h3>
        
        <ExampleBox title="Suspicious Sender Address" good={false}>
          <p>Real: support@instagram.com</p>
          <p>Fake: support@instagram-security.com or instagram.support@gmail.com</p>
          <p className="mt-2 text-xs">Always check the actual email address, not just the display name!</p>
        </ExampleBox>

        <ExampleBox title="Urgent or Threatening Language" good={false}>
          <ul className="mt-2 space-y-1">
            <li>&quot;Your account will be DELETED in 24 hours!&quot;</li>
            <li>&quot;URGENT: Suspicious activity detected&quot;</li>
            <li>&quot;Act NOW or lose access forever&quot;</li>
          </ul>
          <p className="mt-2 text-xs">Legitimate companies rarely use fear tactics or excessive urgency.</p>
        </ExampleBox>

        <ExampleBox title="Poor Grammar and Spelling" good={false}>
          <p>&quot;Dear Valued Costumer, Your acccount has been compromsed. Click hear to verify.&quot;</p>
          <p className="mt-2 text-xs">Real companies have professional editors and spell-check.</p>
        </ExampleBox>

        <ExampleBox title="Suspicious Links" good={false}>
          <p>The email says: &quot;Click here to log in to Facebook&quot;</p>
          <p>But the link actually goes to: facebook-login-secure.sketchy-site.com</p>
          <p className="mt-2 text-xs">Hover over links (without clicking!) to see where they really go.</p>
        </ExampleBox>

        <ContentCard type="info" title="How to Check a Link Without Clicking">
          <ol className="space-y-1 mt-2">
            <li>1. On a computer: Hover your mouse over the link and look at the bottom-left of your browser</li>
            <li>2. On mobile: Long-press the link to see a preview of the URL</li>
            <li>3. If the URL looks suspicious, do not click it!</li>
          </ol>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'real-examples',
    title: 'Real Phishing Examples',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Let&apos;s look at actual phishing attempts that commonly target young people:
        </p>

        <ContentCard type="danger" title="Fake Gaming Giveaway">
          <div className="bg-secondary/50 p-3 rounded mt-2 font-mono text-xs">
            <p>From: fortnite-support@epicgames-verify.com</p>
            <p>Subject: You&apos;ve Won 10,000 Free V-Bucks!</p>
            <p className="mt-2">Congratulations! You&apos;ve been selected to receive FREE V-Bucks! 
            Click here to claim your reward before it expires in 1 hour!</p>
          </div>
          <p className="mt-3"><strong>Why it&apos;s fake:</strong></p>
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li>Epic Games would never email about free V-Bucks</li>
            <li>The email domain is not @epicgames.com</li>
            <li>Creates artificial urgency (&quot;1 hour&quot;)</li>
            <li>If something seems too good to be true, it is</li>
          </ul>
        </ContentCard>

        <ContentCard type="danger" title="Fake Account Verification">
          <div className="bg-secondary/50 p-3 rounded mt-2 font-mono text-xs">
            <p>From: Instagram Security &lt;security@ig-verify.net&gt;</p>
            <p>Subject: Action Required: Verify Your Account</p>
            <p className="mt-2">We detected unusual login activity on your account. 
            To prevent your account from being disabled, please verify your identity 
            by clicking the link below and entering your password.</p>
          </div>
          <p className="mt-3"><strong>Why it&apos;s fake:</strong></p>
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li>Instagram emails come from @instagram.com or @mail.instagram.com</li>
            <li>Instagram never asks you to verify by entering your password via email</li>
            <li>Real security alerts direct you to log in normally through the app</li>
          </ul>
        </ContentCard>

        <ContentCard type="danger" title="Fake Friend in Trouble">
          <div className="bg-secondary/50 p-3 rounded mt-2 font-mono text-xs">
            <p>DM on Discord from &quot;BestFriend2010&quot;:</p>
            <p className="mt-2">&quot;OMG dude I accidentally reported your account instead of someone else. 
            They&apos;re going to ban you! You need to contact this admin right now to fix it: 
            discord-support-admin.com/appeal&quot;</p>
          </div>
          <p className="mt-3"><strong>Why it&apos;s fake:</strong></p>
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li>Discord would contact you directly about reports, not through friends</li>
            <li>The link is not discord.com</li>
            <li>Even if your friend&apos;s account sent this, their account might be hacked</li>
            <li>Contact your friend through a different method to verify</li>
          </ul>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'fake-websites',
    title: 'Spotting Fake Websites',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Scammers create fake websites that look almost identical to real ones. Here is how to 
          tell the difference:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Check the URL Carefully</h3>
        
        <ExampleBox title="Real vs Fake URLs" good={false}>
          <p className="font-mono"><strong>Real:</strong> https://www.instagram.com/accounts/login</p>
          <p className="font-mono mt-1"><strong>Fake:</strong> https://www.1nstagram.com/accounts/login</p>
          <p className="font-mono mt-1"><strong>Fake:</strong> https://instagram.login-verify.com</p>
          <p className="font-mono mt-1"><strong>Fake:</strong> https://www.instagram.com.suspicious-site.net</p>
          <p className="mt-3 text-xs">Notice: Letter substitutions (1 for i), subdomains that aren&apos;t the main site, 
          and the real domain appearing as a subdomain of a different site.</p>
        </ExampleBox>

        <h3 className="text-lg font-semibold mt-6 mb-3">Signs of a Fake Website</h3>
        <StepList
          steps={[
            'The URL has misspellings or extra characters (amaz0n, g00gle, paypa1)',
            'No padlock icon in the address bar (though scammers can have this too)',
            'The design looks slightly off - wrong colors, blurry logos, weird fonts',
            'Links on the page do not work or all lead to the same place',
            'Pop-ups asking for personal information appear immediately',
            'The website asks for more information than necessary',
          ]}
        />

        <ContentCard type="success" title="Safe Practices">
          <ul className="space-y-1 mt-2">
            <li>Type URLs directly instead of clicking links in emails</li>
            <li>Use bookmarks for important sites like your bank or email</li>
            <li>If you are unsure, search for the company on Google and click from there</li>
            <li>Check for https:// and a padlock, but know this alone is not enough</li>
          </ul>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'social-media-scams',
    title: 'Social Media Scams',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Social media platforms are full of scams targeting young people. Here are the most 
          common ones to watch out for:
        </p>

        <ContentCard type="warning" title="Fake Giveaways and Contests">
          <p>
            &quot;We&apos;re giving away 100 iPhones! Just follow us, like this post, share it, and DM 
            us your email to enter!&quot;
          </p>
          <p className="mt-2">
            <strong>Reality:</strong> These accounts collect your information to sell or use for 
            further scams. Real giveaways from verified accounts never ask for personal info via DM.
          </p>
        </ContentCard>

        <ContentCard type="warning" title="Fake Influencer Accounts">
          <p>
            Scammers create accounts that look like popular YouTubers or streamers, then DM 
            followers claiming they won a prize or offering special deals.
          </p>
          <p className="mt-2">
            <strong>How to spot them:</strong> Check for the verification badge, look at the 
            follower count, check when the account was created, and see if the real influencer 
            links to this account.
          </p>
        </ContentCard>

        <ContentCard type="warning" title="Romance Scams">
          <p>
            Someone starts chatting with you, seems really interested in you, and eventually 
            asks for money, gift cards, or personal information.
          </p>
          <p className="mt-2">
            <strong>Red flags:</strong> They cannot video chat, their photos look like stock 
            images, they fall in love very quickly, and they always have emergencies that need money.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Common DM Scams</h3>
        <ExampleBox title="Scam Messages to Watch For" good={false}>
          <ul className="space-y-2 mt-2">
            <li>&quot;OMG is this you in this video?&quot; + suspicious link</li>
            <li>&quot;I can&apos;t believe you posted this...&quot; + link</li>
            <li>&quot;You won our giveaway! DM me to claim&quot;</li>
            <li>&quot;I can get you verified/famous for a small fee&quot;</li>
            <li>&quot;Check out this app that pays you money!&quot;</li>
            <li>&quot;Can you vote for me in this contest?&quot; + link to fake site</li>
          </ul>
        </ExampleBox>
      </>
    ),
  },
  {
    id: 'gaming-scams',
    title: 'Gaming-Specific Scams',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          The gaming world is full of scams that specifically target players. Here are the 
          most common ones:
        </p>

        <ContentCard type="danger" title="Free V-Bucks/Robux/Coins Generators">
          <p>
            Websites claiming to generate free in-game currency DO NOT WORK. They are designed 
            to steal your login credentials and personal information. No website can magically 
            create currency in Fortnite, Roblox, or any other game.
          </p>
        </ContentCard>

        <ContentCard type="danger" title="Account Trading Scams">
          <p>
            Someone offers to trade accounts, promising you a high-level account with rare items. 
            You give them your login first, and they disappear with both accounts. This also 
            violates the terms of service of most games.
          </p>
        </ContentCard>

        <ContentCard type="danger" title="Fake Item Duplicators">
          <p>
            &quot;Give me your items to duplicate them!&quot; - This is 100% a scam. There is no way to 
            duplicate items. You will simply lose whatever you give away.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Steam and Game Platform Scams</h3>
        <ExampleBox title="Common Gaming Platform Scams" good={false}>
          <ul className="space-y-2 mt-2">
            <li>&quot;Someone reported your account. Contact this Steam admin...&quot;</li>
            <li>&quot;Your account will be banned for fraud. Visit this link to appeal...&quot;</li>
            <li>&quot;I accidentally reported you, now you need to verify with a Steam admin&quot;</li>
            <li>&quot;Vote for my team&quot; links that ask you to sign in through fake sites</li>
          </ul>
        </ExampleBox>

        <QuickFact>
          Steam, Epic Games, Roblox, and other gaming platforms will NEVER contact you through 
          random users or ask you to verify your account through external links. All official 
          communication happens through the platform itself.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'protecting-yourself',
    title: 'How to Protect Yourself',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Now that you know what to look for, here is how to stay safe:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">The STOP Method</h3>
        <StepList
          steps={[
            'STOP - Do not click anything immediately. Take a breath and think.',
            'THINK - Does this message make sense? Would this company really contact me this way?',
            'OBSERVE - Check for red flags: sender address, URLs, grammar, urgency.',
            'PROTECT - When in doubt, go directly to the official website or app instead of clicking links.',
          ]}
        />

        <ContentCard type="success" title="Golden Rules for Staying Safe">
          <ul className="space-y-1 mt-2">
            <li>Never enter passwords after clicking a link in an email or message</li>
            <li>If something seems too good to be true, it is</li>
            <li>Verify urgent requests through a different communication channel</li>
            <li>Never share verification codes with anyone, even people claiming to be support</li>
            <li>When in doubt, ask a trusted adult</li>
          </ul>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">What to Do If You Fell for a Scam</h3>
        <StepList
          steps={[
            'Do not panic - it happens to many people, even adults',
            'Immediately change the password for any account you entered credentials on',
            'Change passwords for other accounts if you use the same password',
            'Enable two-factor authentication on all important accounts',
            'Tell a parent or trusted adult what happened',
            'Report the scam to the platform where you encountered it',
            'If money was involved, tell your parents immediately so they can contact the bank',
          ]}
        />
      </>
    ),
  },
  {
    id: 'reporting-scams',
    title: 'Reporting Phishing and Scams',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Reporting scams helps protect others and can help take down scammer operations. 
          Here is where to report different types of scams:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Where to Report</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li><strong>Email phishing:</strong> Forward to the real company (e.g., phishing@instagram.com) and report as spam</li>
          <li><strong>Social media scams:</strong> Use the Report feature on the platform</li>
          <li><strong>Gaming scams:</strong> Report through the game&apos;s support system</li>
          <li><strong>Text message scams:</strong> Forward to 7726 (SPAM) in most countries</li>
          <li><strong>Serious scams:</strong> Tell a parent to report to the FTC (in the US) or equivalent</li>
        </ul>

        <ContentCard type="info" title="What Information to Include When Reporting">
          <ul className="space-y-1 mt-2">
            <li>Screenshot of the scam message or website</li>
            <li>The sender&apos;s email address or username</li>
            <li>Any links included in the message (but do not click them)</li>
            <li>When and where you received the message</li>
          </ul>
        </ContentCard>

        <QuickFact>
          Every report matters! Even if you did not fall for the scam, reporting it helps 
          platforms identify and remove scammers before they can trick someone else.
        </QuickFact>
      </>
    ),
  },
]

export default function PhishingLesson() {
  return (
    <LessonPage
      title="Phishing & Scams"
      description="Learn to recognize and avoid fake emails, messages, and websites designed to steal your personal information and money."
      icon={AlertTriangle}
      duration="25 min read"
      difficulty="Beginner"
      sections={sections}
      prevLesson={{ href: '/lessons/passwords', title: 'Passwords' }}
      nextLesson={{ href: '/lessons/deepfakes', title: 'Deepfakes' }}
      quizHref="/quizzes/phishing"
    />
  )
}
