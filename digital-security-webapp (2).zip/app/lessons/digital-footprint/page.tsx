import { LessonPage } from "@/components/lesson-page"
import {
  Section,
  Paragraph,
  BulletList,
  NumberedList,
  WarningBox,
  TipBox,
  ExampleBox,
  QuizQuestion,
} from "@/components/lesson-content"

export const metadata = {
  title: "Digital Footprint | CyberSafe Academy",
  description: "Understand how your online activities create a permanent record and learn to manage your digital reputation.",
}

export default function DigitalFootprintPage() {
  return (
    <LessonPage
      title="Digital Footprint"
      description="Your online actions create a permanent record - learn to manage it wisely"
      duration="18 min"
      difficulty="Intermediate"
      prevLesson={{ href: "/lessons/gaming-safety", title: "Gaming Safety" }}
      nextLesson={{ href: "/lessons/wifi-security", title: "WiFi Security" }}
    >
      <Section title="What is a Digital Footprint?">
        <Paragraph>
          Imagine walking on a sandy beach - every step you take leaves a footprint behind. The internet works the same way. Every website you visit, post you make, photo you share, and comment you write leaves a digital footprint. Unlike footprints in sand, digital footprints do not wash away with the tide - they can last forever.
        </Paragraph>
        <Paragraph>
          Your digital footprint is the trail of data you leave behind when you use the internet. This includes everything from your social media posts to websites you visit, emails you send, and information you share online. Understanding and managing your digital footprint is crucial for your future.
        </Paragraph>
      </Section>

      <Section title="Active vs. Passive Digital Footprints">
        <Paragraph>
          There are two types of digital footprints:
        </Paragraph>

        <BulletList
          items={[
            "Active footprint: Information you deliberately share - social media posts, comments, photos, videos, profile information, and online forms you fill out.",
            "Passive footprint: Information collected about you without you actively sharing it - your IP address, browsing history, cookies tracking your behavior, location data, and device information.",
          ]}
        />

        <ExampleBox title="Your Passive Footprint in Action">
          When you visit an online store and look at sneakers, you might notice ads for those exact sneakers following you around the internet for days. That is your passive footprint at work - websites track what you view and share that information with advertisers.
        </ExampleBox>
      </Section>

      <Section title="Who Looks at Your Digital Footprint?">
        <Paragraph>
          You might think only your friends see what you post online, but many others might look at your digital footprint:
        </Paragraph>

        <BulletList
          items={[
            "College admissions officers: Many universities research applicants' social media before making decisions.",
            "Scholarship committees: They often check online presence when awarding money for education.",
            "Future employers: Most employers Google candidates before interviews or job offers.",
            "Coaches and recruiters: Athletic and academic recruiters research students online.",
            "Law enforcement: If you are ever involved in legal issues, your online activity can be examined.",
            "Insurance companies: Some look at social media to assess risk.",
            "Hackers and scammers: They use your online information to target you.",
            "Anyone with internet access: Even with privacy settings, things can be screenshot and shared.",
          ]}
        />

        <WarningBox title="Real Consequences">
          Students have lost college acceptances, scholarships, and job offers because of things they posted online - sometimes years before. A Harvard study found that 70% of employers check social media during hiring. What seems funny to you and your friends might look very different to a college admissions officer.
        </WarningBox>
      </Section>

      <Section title="The Permanence of the Internet">
        <Paragraph>
          One of the most important things to understand about digital footprints is their permanence:
        </Paragraph>

        <NumberedList
          items={[
            "Deleting is not erasing: When you delete a post, it may still exist on servers, in backups, or in screenshots others have taken.",
            "Screenshots are forever: Anyone can screenshot your content before you delete it.",
            "The Wayback Machine: Websites are archived by services that store old versions of pages.",
            "Data breaches: Companies that have your data might get hacked, exposing information you thought was private.",
            "Cached versions: Search engines often store cached copies of web pages.",
            "Shared content spreads: Once someone shares your content, you lose control over it.",
          ]}
        />

        <ExampleBox title="The 'Delete' Illusion">
          A teenager posted an embarrassing photo at a party, then deleted it 10 minutes later. They thought it was gone forever. But a classmate had already screenshot it and shared it in a group chat. That &quot;deleted&quot; photo spread to hundreds of people and resurfaced years later during college applications.
        </ExampleBox>
      </Section>

      <Section title="Managing Your Active Footprint">
        <Paragraph>
          You have control over your active digital footprint. Here is how to manage it wisely:
        </Paragraph>

        <NumberedList
          items={[
            "Think before you post: Before sharing anything, ask yourself: Would I be okay with my grandmother, future boss, or college admissions officer seeing this?",
            "Use the 24-hour rule: If you are emotional, wait a day before posting. You might feel differently tomorrow.",
            "Be kind online: Bullying comments, mean jokes, and cruel behavior create a negative footprint that reflects poorly on you.",
            "Check your privacy settings: Regularly review who can see your posts and profile information.",
            "Google yourself: See what comes up when someone searches your name. You might be surprised.",
            "Use separate accounts: Consider keeping personal and public accounts separate.",
            "Be careful with location sharing: Posting your location can be a safety and privacy risk.",
            "Think about context: A joke among friends might be misunderstood by strangers who see it later.",
          ]}
        />

        <TipBox title="The Billboard Test">
          Before posting anything online, imagine it printed on a giant billboard in your town with your name attached. If you would not want that, do not post it. The internet is essentially a public billboard that never comes down.
        </TipBox>
      </Section>

      <Section title="Minimizing Your Passive Footprint">
        <Paragraph>
          While you cannot completely eliminate your passive footprint, you can reduce it:
        </Paragraph>

        <BulletList
          items={[
            "Use private browsing: Incognito or private mode prevents some tracking (but not all).",
            "Clear cookies regularly: Cookies track your browsing behavior across websites.",
            "Use privacy-focused browsers: Browsers like Firefox or Brave offer more privacy features.",
            "Limit app permissions: Only give apps the permissions they truly need.",
            "Use a VPN: A Virtual Private Network hides your IP address and encrypts your traffic.",
            "Opt out of tracking: Many websites let you opt out of personalized advertising.",
            "Read privacy policies: Understand what data apps and websites collect.",
            "Use search engines that do not track: DuckDuckGo does not store your search history.",
          ]}
        />

        <ExampleBox title="The App Permissions Reality">
          A flashlight app should not need access to your contacts, microphone, or location. Yet many free apps request far more permissions than they need because they make money by collecting and selling your data. Always check and limit app permissions.
        </ExampleBox>
      </Section>

      <Section title="Building a Positive Digital Footprint">
        <Paragraph>
          Your digital footprint does not have to be negative - you can intentionally create a positive one:
        </Paragraph>

        <BulletList
          items={[
            "Share accomplishments: Post about academic achievements, volunteer work, and positive activities.",
            "Showcase your skills: Share projects, art, writing, or other talents.",
            "Be helpful online: Answer questions, share useful information, and contribute positively to communities.",
            "Support good causes: Share and engage with content that reflects your values positively.",
            "Create content: Start a blog, YouTube channel, or portfolio showcasing your interests and abilities.",
            "Engage professionally: Join groups related to your career interests and participate constructively.",
            "Show your personality: It is okay to be yourself - just be the best version of yourself.",
          ]}
        />

        <TipBox title="Build Your Portfolio">
          Use your digital footprint intentionally to create an online portfolio. By the time you apply to college or jobs, you can point to years of positive content showcasing your skills, interests, and character.
        </TipBox>
      </Section>

      <Section title="Cleaning Up Your Digital Footprint">
        <Paragraph>
          If you have content online you regret, here are steps to clean it up:
        </Paragraph>

        <NumberedList
          items={[
            "Audit your social media: Go through all your accounts and delete posts you would not want others to see.",
            "Google yourself: Search your name and see what comes up. Set up Google Alerts for your name.",
            "Delete unused accounts: Old accounts you forgot about still contain your data. Delete them.",
            "Ask others to remove content: If someone posted something about you, politely ask them to take it down.",
            "Contact websites directly: Many websites will remove content if you request it.",
            "Use search engine removal tools: Google has tools to request removal of certain personal information.",
            "Create positive content: New, positive content can push down old, negative content in search results.",
            "Consider professional help: For serious reputation issues, there are services that help clean up digital footprints.",
          ]}
        />

        <WarningBox title="Cannot Remove Everything">
          Some things cannot be removed from the internet. If content has been widely shared, screenshot, or archived, it may be impossible to completely eliminate. This is why preventing problems is better than trying to fix them later.
        </WarningBox>
      </Section>

      <Section title="Your Future Self Will Thank You">
        <Paragraph>
          The decisions you make online today affect your future self:
        </Paragraph>

        <BulletList
          items={[
            "College applications are 4-6 years away for middle schoolers - what you post now will still exist",
            "Jobs you apply for in 10-15 years might check your entire online history",
            "Relationships can be affected by old posts resurfacing",
            "Your values and opinions will change - posts reflecting immature views can haunt you",
            "What seems hilarious at 14 might be embarrassing at 24",
            "Professional opportunities can be won or lost based on your digital footprint",
          ]}
        />

        <ExampleBox title="The Student Who Got Into Harvard">
          A student built a positive digital footprint throughout high school by blogging about their science fair projects, sharing volunteer work, and engaging constructively in online communities about their interests. When Harvard admissions Googled them, they found a thoughtful, accomplished young person - exactly what they wanted to admit.
        </ExampleBox>
      </Section>

      <Section title="Test Your Knowledge">
        <QuizQuestion
          question="You posted something embarrassing and deleted it immediately. Is it gone forever?"
          options={[
            "Yes, deleting removes it completely from the internet",
            "No, someone could have screenshot it or it might be cached or backed up",
            "Yes, as long as no one liked or commented on it",
            "Only if you also clear your browser history",
          ]}
          correctIndex={1}
          explanation="Deleting content does not guarantee it is gone. Someone might have screenshot it, search engines might have cached it, or it might exist in backups. Always assume anything you post could be permanent."
        />

        <QuizQuestion
          question="A college admissions officer searching your name online is an example of them looking at your:"
          options={[
            "Credit score",
            "Digital footprint",
            "Browser history",
            "Private messages",
          ]}
          correctIndex={1}
          explanation="When someone searches your name and views publicly available information about you online, they are looking at your digital footprint - the trail of data you leave behind on the internet."
        />

        <QuizQuestion
          question="What is the best approach to managing your digital footprint?"
          options={[
            "Avoid using the internet entirely",
            "Delete everything you post after 24 hours",
            "Think carefully before posting and intentionally build a positive online presence",
            "Only post anonymously so nothing can be traced back to you",
          ]}
          correctIndex={2}
          explanation="The best approach is to be thoughtful about what you share and intentionally create a positive digital footprint that showcases your best qualities and accomplishments."
        />
      </Section>

      <Section title="Key Takeaways">
        <BulletList
          items={[
            "Your digital footprint is the trail of data you leave online - it can last forever",
            "Both active sharing and passive tracking contribute to your footprint",
            "Many people look at your digital footprint: colleges, employers, scholarships, and more",
            "Deleting content does not guarantee it is gone - screenshots and caches exist",
            "Use the billboard test: only post what you would want on a public billboard with your name",
            "You can intentionally build a positive digital footprint to help your future",
            "Regularly audit your online presence and clean up content you regret",
            "Privacy settings help but are not foolproof - assume anything could become public",
          ]}
        />
      </Section>
    </LessonPage>
  )
}
