import { LessonPage } from "@/components/lesson-page"
import {
  Section,
  Paragraph,
  BulletList,
  NumberedList,
  WarningBox,
  TipBox,
  ExampleBox,
  QuizQuestion,
} from "@/components/lesson-content"

export const metadata = {
  title: "WiFi & Network Security | CyberSafe Academy",
  description: "Learn how to stay safe on public WiFi networks and protect your home network from intruders.",
}

export default function WiFiSecurityPage() {
  return (
    <LessonPage
      title="WiFi & Network Security"
      description="Protect yourself on public networks and secure your home WiFi"
      duration="15 min"
      difficulty="Intermediate"
      prevLesson={{ href: "/lessons/digital-footprint", title: "Digital Footprint" }}
      nextLesson={{ href: "/quizzes", title: "Test Your Knowledge" }}
    >
      <Section title="Why WiFi Security Matters">
        <Paragraph>
          WiFi is everywhere - at home, school, coffee shops, airports, and hotels. While wireless internet is incredibly convenient, it can also be risky if you are not careful. Hackers can intercept information sent over insecure networks, and fake WiFi networks can trick you into connecting to them.
        </Paragraph>
        <Paragraph>
          Understanding WiFi security helps you stay safe whether you are at home or using public networks while traveling or hanging out with friends.
        </Paragraph>
      </Section>

      <Section title="The Dangers of Public WiFi">
        <Paragraph>
          Free public WiFi at cafes, libraries, and airports is convenient, but it comes with risks:
        </Paragraph>

        <BulletList
          items={[
            "Man-in-the-Middle Attacks: Hackers can position themselves between you and the WiFi connection, intercepting everything you send and receive.",
            "Fake hotspots (Evil Twin): A hacker creates a WiFi network with a legitimate-sounding name (like 'Starbucks_Free_WiFi') to trick you into connecting.",
            "Packet sniffing: Special software can capture unencrypted data traveling over the network.",
            "Malware distribution: Some public networks are compromised and can push malware to your device.",
            "Session hijacking: Hackers can steal your login sessions and access your accounts.",
          ]}
        />

        <ExampleBox title="The Coffee Shop Trap">
          You are at a coffee shop called &quot;Bean There&quot; and see two WiFi networks: &quot;BeanThere_Guest&quot; and &quot;Bean_There_Free_WiFi&quot;. One is the real network, and one is a hacker sitting nearby who created a fake network to steal data from anyone who connects. How do you know which is which? Ask an employee what the official network name is.
        </ExampleBox>
      </Section>

      <Section title="How to Stay Safe on Public WiFi">
        <Paragraph>
          If you must use public WiFi, follow these safety practices:
        </Paragraph>

        <NumberedList
          items={[
            "Verify the network name: Ask an employee for the exact name of the official WiFi network.",
            "Use HTTPS websites: Only visit websites that show HTTPS (the padlock icon) in the address bar. Your browser may warn you about non-secure sites.",
            "Avoid sensitive activities: Do not log into banking, shopping, or other sensitive accounts on public WiFi.",
            "Disable auto-connect: Turn off the setting that automatically connects to available WiFi networks.",
            "Use a VPN: A Virtual Private Network encrypts all your traffic, making it unreadable to hackers.",
            "Turn off sharing: Disable file sharing and AirDrop when on public networks.",
            "Forget the network: After using public WiFi, tell your device to forget the network so it will not auto-connect later.",
            "Use mobile data instead: For sensitive tasks, using your phone's cellular data is safer than public WiFi.",
          ]}
        />

        <TipBox title="VPN: Your Digital Shield">
          A VPN (Virtual Private Network) creates an encrypted tunnel for your internet traffic. Even if someone intercepts your data on public WiFi, they cannot read it. There are many reputable VPN services available, some free and some paid.
        </TipBox>
      </Section>

      <Section title="Understanding HTTPS">
        <Paragraph>
          HTTPS is your first line of defense online:
        </Paragraph>

        <BulletList
          items={[
            "HTTPS stands for HyperText Transfer Protocol Secure",
            "It encrypts data between your browser and the website",
            "Look for the padlock icon in your browser's address bar",
            "Never enter passwords or personal information on non-HTTPS sites",
            "Most browsers now warn you when visiting non-secure sites",
            "Even with HTTPS, be cautious on public WiFi - hackers can still see which websites you visit, just not the content",
          ]}
        />

        <WarningBox title="HTTPS is Not Everything">
          HTTPS protects your data in transit, but it does not mean a website is trustworthy. Scam sites can have HTTPS too. Always verify you are on the correct website by checking the full URL, not just looking for the padlock.
        </WarningBox>
      </Section>

      <Section title="Securing Your Home WiFi">
        <Paragraph>
          Your home network needs protection too. Here is how to secure it:
        </Paragraph>

        <NumberedList
          items={[
            "Change the default router password: Routers come with default passwords that hackers know. Change it to something strong and unique.",
            "Update router firmware: Router manufacturers release security updates. Keep your router updated.",
            "Use WPA3 or WPA2 encryption: These are the current secure standards. Never use WEP - it is easily hackable.",
            "Create a strong WiFi password: Use a long, random password that is different from your router admin password.",
            "Change the default network name (SSID): Do not use a name that identifies you or your router model.",
            "Enable the firewall: Most routers have a built-in firewall. Make sure it is turned on.",
            "Create a guest network: Give visitors a separate network so they do not have access to your main devices.",
            "Disable WPS: WiFi Protected Setup has known vulnerabilities. Turn it off.",
          ]}
        />

        <ExampleBox title="The Default Password Problem">
          Many people never change their router&apos;s default password. Hackers have lists of default passwords for every router model. A hacker driving by your house could potentially access your network, see your traffic, and even access devices on your network - all because you never changed that default password.
        </ExampleBox>
      </Section>

      <Section title="Recognizing Fake WiFi Networks">
        <Paragraph>
          Learn to spot potentially dangerous networks:
        </Paragraph>

        <BulletList
          items={[
            "Networks that do not require a password in places where they should",
            "Multiple similar network names (e.g., 'Airport_WiFi' and 'Airport_WiFi_Free')",
            "Networks with generic names like 'Free WiFi' or 'Public WiFi'",
            "Networks that ask you to install software or certificates to connect",
            "Connection speeds that seem unusually slow (could indicate traffic interception)",
            "Unexpected login pages or captive portals that look different from usual",
          ]}
        />

        <TipBox title="When in Doubt, Ask">
          If you are unsure about a WiFi network, ask an employee or staff member what the official network name is. Taking 30 seconds to verify is better than having your data stolen.
        </TipBox>
      </Section>

      <Section title="Bluetooth and Other Wireless Risks">
        <Paragraph>
          WiFi is not the only wireless risk. Bluetooth and other connections need attention too:
        </Paragraph>

        <BulletList
          items={[
            "Turn off Bluetooth when not using it: Open Bluetooth connections can be exploited.",
            "Set devices to non-discoverable: This prevents others from seeing your device.",
            "Be careful with Bluetooth pairing: Only pair with devices you own and trust.",
            "Update device firmware: Bluetooth vulnerabilities are regularly discovered and patched.",
            "Disable AirDrop from strangers: Set AirDrop to 'Contacts Only' or off to prevent unwanted files.",
            "Be cautious with USB ports: Public charging stations can sometimes be compromised.",
          ]}
        />

        <WarningBox title="Bluejacking and Bluesnarfing">
          Hackers can use Bluetooth vulnerabilities to send you unwanted messages (bluejacking) or even access your device&apos;s data (bluesnarfing). Keep Bluetooth off when you are not actively using it.
        </WarningBox>
      </Section>

      <Section title="What Information is at Risk">
        <Paragraph>
          On an insecure network, hackers might be able to see:
        </Paragraph>

        <BulletList
          items={[
            "Websites you visit (even with HTTPS, they can see the domain names)",
            "Unencrypted emails and messages",
            "Login credentials for non-HTTPS sites",
            "Files you download or upload",
            "Your device name and type",
            "Your location and movement patterns if you connect to the same networks regularly",
          ]}
        />

        <ExampleBox title="The Hotel WiFi Mistake">
          Someone logged into their bank account on hotel WiFi without using a VPN. A hacker on the same network intercepted their session and gained access to their bank account. The person did not realize anything was wrong until they saw unauthorized transactions the next day.
        </ExampleBox>
      </Section>

      <Section title="Test Your Knowledge">
        <QuizQuestion
          question="You are at a coffee shop and see two WiFi networks: 'CoffeeShop_WiFi' and 'Free_CoffeeShop_Guest'. What should you do?"
          options={[
            "Connect to 'Free_CoffeeShop_Guest' because it has 'Free' in the name",
            "Connect to whichever has the stronger signal",
            "Ask an employee which network is the official one",
            "Connect to both and see which works better",
          ]}
          correctIndex={2}
          explanation="Always verify the official network name with staff. Hackers often create fake networks with similar names to the legitimate one. Taking a moment to ask can protect you from connecting to a malicious network."
        />

        <QuizQuestion
          question="What is the safest way to check your bank account when you are away from home?"
          options={[
            "Use the free WiFi at a cafe",
            "Use your phone's mobile data or a VPN",
            "Wait until you find a network with a password",
            "Use any WiFi as long as the website has HTTPS",
          ]}
          correctIndex={1}
          explanation="Mobile data is generally safer than public WiFi because it is encrypted and goes directly to your carrier. Using a VPN on any connection adds another layer of protection for sensitive activities like banking."
        />

        <QuizQuestion
          question="Your home router still has its default password from when it was installed. This is:"
          options={[
            "Fine, as long as you have a strong WiFi password",
            "A security risk because hackers know default passwords",
            "Only a problem if you share your WiFi with neighbors",
            "Good, because default passwords are created by security experts",
          ]}
          correctIndex={1}
          explanation="Default router passwords are publicly known and listed online. Hackers can easily access routers that still use default passwords, potentially viewing all your network traffic or accessing your devices."
        />
      </Section>

      <Section title="Key Takeaways">
        <BulletList
          items={[
            "Public WiFi is convenient but risky - hackers can intercept your data or create fake networks",
            "Always verify the official network name with staff before connecting",
            "Use a VPN for an extra layer of security on public networks",
            "Only visit HTTPS websites and avoid sensitive activities on public WiFi",
            "Secure your home network by changing default passwords and using WPA3/WPA2",
            "Turn off Bluetooth and auto-connect features when not needed",
            "When in doubt, use mobile data instead of untrusted WiFi",
            "HTTPS protects your data but does not guarantee a website is trustworthy",
          ]}
        />
      </Section>
    </LessonPage>
  )
}
