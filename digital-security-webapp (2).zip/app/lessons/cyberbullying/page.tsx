import { Smartphone } from 'lucide-react'
import { LessonPage } from '@/components/lesson-page'
import { ContentCard, ExampleBox, QuickFact, StepList } from '@/components/lesson-content'

const sections = [
  {
    id: 'what-is-cyberbullying',
    title: 'What Is Cyberbullying?',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Cyberbullying is bullying that takes place using digital devices and platforms. Unlike 
          traditional bullying, it can happen 24/7, follow you anywhere, and reach a much larger 
          audience. Understanding cyberbullying is the first step to stopping it.
        </p>
        
        <ContentCard type="warning" title="Why Cyberbullying Is Serious">
          <p>
            Cyberbullying can be even more harmful than in-person bullying because: it can happen 
            constantly with no safe space, content can spread rapidly to many people, evidence 
            can be permanent and resurface later, and it is harder to identify and stop the bullies.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Forms of Cyberbullying</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li><strong>Harassment:</strong> Repeatedly sending offensive, threatening, or mean messages</li>
          <li><strong>Exclusion:</strong> Intentionally leaving someone out of online groups or activities</li>
          <li><strong>Outing:</strong> Sharing someone&apos;s private information or secrets publicly</li>
          <li><strong>Impersonation:</strong> Pretending to be someone to damage their reputation</li>
          <li><strong>Cyberstalking:</strong> Repeated harassment that includes threats</li>
          <li><strong>Doxing:</strong> Publishing someone&apos;s private information (address, phone, etc.)</li>
          <li><strong>Image-based abuse:</strong> Sharing embarrassing or private photos without consent</li>
        </ul>

        <QuickFact>
          About 37% of students between ages 12-17 have experienced cyberbullying at some point. 
          But many cases go unreported because victims feel embarrassed or fear retaliation.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'recognizing-cyberbullying',
    title: 'Recognizing Cyberbullying',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Cyberbullying can take many forms, and sometimes it is not obvious. Here are examples 
          of what cyberbullying looks like:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Direct Cyberbullying</h3>
        
        <ExampleBox title="Threatening Messages" good={false}>
          <ul className="space-y-1 mt-2">
            <li>&quot;I&apos;m going to make your life miserable&quot;</li>
            <li>&quot;You better not come to school tomorrow&quot;</li>
            <li>&quot;Everyone hates you, you should just disappear&quot;</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Constant Harassment" good={false}>
          <ul className="space-y-1 mt-2">
            <li>Sending dozens of hateful messages daily</li>
            <li>Commenting negatively on every post someone makes</li>
            <li>Creating multiple accounts to continue harassment after being blocked</li>
          </ul>
        </ExampleBox>

        <h3 className="text-lg font-semibold mt-6 mb-3">Indirect Cyberbullying</h3>
        
        <ExampleBox title="Spreading Rumors" good={false}>
          <ul className="space-y-1 mt-2">
            <li>Creating fake stories about someone and sharing them</li>
            <li>Taking screenshots of private conversations out of context</li>
            <li>Making up relationship drama about someone</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Social Manipulation" good={false}>
          <ul className="space-y-1 mt-2">
            <li>Organizing others to unfollow or block someone</li>
            <li>Creating group chats specifically to exclude someone</li>
            <li>Convincing friends to stop talking to someone</li>
          </ul>
        </ExampleBox>

        <ContentCard type="info" title="The Difference Between Drama and Bullying">
          <p>
            <strong>Drama:</strong> A one-time argument or disagreement between people with equal power
          </p>
          <p className="mt-2">
            <strong>Bullying:</strong> Repeated, intentional behavior involving a power imbalance, 
            where one person or group has more social power than the target
          </p>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'if-you-are-targeted',
    title: 'If You Are Being Cyberbullied',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Being cyberbullied can feel overwhelming and isolating. Here is what to do:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Immediate Steps</h3>
        <StepList
          steps={[
            'Do not respond or engage with the bully - responses often encourage them',
            'Take screenshots of everything - dates, times, usernames, messages',
            'Block the person on all platforms',
            'Report the behavior to the platform (Instagram, TikTok, Discord, etc.)',
            'Tell a trusted adult - parent, teacher, school counselor',
            'Save all evidence in a safe place',
          ]}
        />

        <ContentCard type="success" title="Why You Should Not Respond">
          <p>
            Bullies want a reaction. When you respond - even to defend yourself - you give them 
            what they want and often make the situation worse. Staying silent is not weakness; 
            it is a strategic choice that takes away their power.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Taking Care of Yourself</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Remember: This is not your fault, no matter what the bully says</li>
          <li>Talk to friends, family, or a counselor about how you are feeling</li>
          <li>Take breaks from social media if needed</li>
          <li>Focus on activities and people that make you feel good</li>
          <li>Know that you are not alone - many people experience this</li>
        </ul>

        <ContentCard type="danger" title="When to Get Help Immediately">
          <p>Contact a trusted adult right away if:</p>
          <ul className="space-y-1 mt-2">
            <li>You receive threats of physical violence</li>
            <li>Someone is sharing private or explicit images of you</li>
            <li>The bullying is affecting your mental health severely</li>
            <li>You feel unsafe at school or in your community</li>
            <li>You have any thoughts of hurting yourself</li>
          </ul>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'reporting-cyberbullying',
    title: 'Reporting Cyberbullying',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Reporting cyberbullying helps stop the abuse and protects others from being targeted 
          by the same person. Here is how to report effectively:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">How to Report on Major Platforms</h3>
        
        <ExampleBox title="Instagram">
          <ul className="space-y-1 mt-2">
            <li>Tap the three dots on a post or profile</li>
            <li>Select &quot;Report&quot; and follow the prompts</li>
            <li>For DMs: Hold the message, tap &quot;Report&quot;</li>
            <li>You can also restrict users to limit their interaction with you</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="TikTok">
          <ul className="space-y-1 mt-2">
            <li>Long press on the video or go to the profile</li>
            <li>Tap the share icon and select &quot;Report&quot;</li>
            <li>Choose &quot;Bullying and harassment&quot; as the reason</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Discord">
          <ul className="space-y-1 mt-2">
            <li>Right-click on the message or user</li>
            <li>Select &quot;Report&quot; from the menu</li>
            <li>For server issues, report to server moderators first</li>
            <li>For serious issues, report directly to Discord Trust &amp; Safety</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Snapchat">
          <ul className="space-y-1 mt-2">
            <li>Press and hold on the snap or chat</li>
            <li>Tap &quot;Report&quot;</li>
            <li>Select the appropriate category</li>
          </ul>
        </ExampleBox>

        <h3 className="text-lg font-semibold mt-6 mb-3">Reporting to School</h3>
        <ContentCard type="info" title="Schools Can Help">
          <p>
            Most schools have cyberbullying policies, even for incidents that happen outside 
            of school, if they affect students&apos; ability to learn. Report to your school 
            counselor or principal and provide your evidence.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">When to Involve Law Enforcement</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Threats of violence or physical harm</li>
          <li>Stalking behavior</li>
          <li>Sexual harassment or sharing of intimate images</li>
          <li>Extortion or blackmail</li>
          <li>Hate crimes based on race, religion, sexual orientation, etc.</li>
        </ul>
      </>
    ),
  },
  {
    id: 'being-an-upstander',
    title: 'Being an Upstander, Not a Bystander',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          If you see cyberbullying happening to someone else, you have the power to help. 
          An &quot;upstander&quot; is someone who speaks up and takes action against bullying, 
          while a &quot;bystander&quot; watches but does nothing.
        </p>

        <ContentCard type="success" title="Why Upstanders Matter">
          <p>
            Studies show that when bystanders intervene, bullying stops within 10 seconds 
            57% of the time. Your action can make a real difference. Standing by silently 
            can make victims feel even more alone and can encourage bullies to continue.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">How to Be an Upstander</h3>
        <StepList
          steps={[
            'Do not like, share, or comment on bullying posts',
            'Report the bullying content to the platform',
            'Reach out privately to the person being bullied to offer support',
            'If safe, publicly show support: "That is not okay" or "Leave them alone"',
            'Tell a trusted adult about what you saw',
            'Include the target in conversations and activities to show they are not alone',
          ]}
        />

        <ExampleBox title="What to Say to Support Someone" good={true}>
          <ul className="space-y-1 mt-2">
            <li>&quot;I saw what happened and I&apos;m sorry you are going through this&quot;</li>
            <li>&quot;That person was wrong to say that. None of it is true.&quot;</li>
            <li>&quot;I&apos;m here if you want to talk&quot;</li>
            <li>&quot;Want me to report it with you? We can tell a teacher together.&quot;</li>
          </ul>
        </ExampleBox>

        <ContentCard type="warning" title="What NOT to Do">
          <ul className="space-y-1 mt-2">
            <li>Do not join in or laugh, even if others are doing it</li>
            <li>Do not forward or share bullying content, even to show others how bad it is</li>
            <li>Do not try to &quot;get back&quot; at the bully - that becomes bullying too</li>
            <li>Do not pressure the victim to respond in a certain way</li>
          </ul>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'avoiding-becoming-a-bully',
    title: 'Avoiding Becoming a Bully',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Sometimes people engage in cyberbullying without realizing it. The anonymity and 
          distance of online communication can make it easier to say hurtful things. Here is 
          how to make sure you are not part of the problem:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Things That Might Be Cyberbullying</h3>
        
        <ExampleBox title="You Might Be Cyberbullying If..." good={false}>
          <ul className="space-y-1 mt-2">
            <li>You share embarrassing photos or videos of someone without their permission</li>
            <li>You create group chats to talk about or exclude someone</li>
            <li>You post negative comments on someone&apos;s content repeatedly</li>
            <li>You share screenshots of private conversations</li>
            <li>You &quot;joke&quot; about someone in ways that hurt them</li>
            <li>You pile on when others are criticizing someone</li>
          </ul>
        </ExampleBox>

        <ContentCard type="info" title="The Online Disinhibition Effect">
          <p>
            People often say things online that they would never say face-to-face. The distance, 
            anonymity, and lack of immediate feedback can make cruel comments feel less harmful. 
            But they are not. Before posting anything about someone, ask yourself: &quot;Would I say 
            this directly to their face?&quot;
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">&quot;Just Joking&quot; Is Not an Excuse</h3>
        <p className="text-muted-foreground mb-4">
          Many people defend hurtful comments by saying they were &quot;just joking.&quot; But:
        </p>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>If the other person is not laughing, it is not a joke</li>
          <li>Repeated &quot;jokes&quot; at someone&apos;s expense is harassment</li>
          <li>Humor does not erase the impact of hurtful words</li>
          <li>The target&apos;s feelings matter more than your intentions</li>
        </ul>

        <QuickFact>
          The &quot;Golden Rule&quot; applies online too: Treat others online the way you would want to 
          be treated. If you would not want it done to you, do not do it to others.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'specific-scenarios',
    title: 'Handling Specific Scenarios',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Here are some specific cyberbullying scenarios and how to handle them:
        </p>

        <ContentCard type="danger" title="Someone Created a Fake Account of You">
          <StepList
            steps={[
              'Screenshot the fake account and all its posts',
              'Report the account to the platform as impersonation',
              'Tell friends and followers that the account is not you',
              'Report to school if the creator is a classmate',
              'Consider posting on your real account about the fake one',
            ]}
          />
        </ContentCard>

        <ContentCard type="danger" title="Embarrassing Photo or Video Is Being Shared">
          <StepList
            steps={[
              'Report the content to every platform where it appears',
              'Ask trusted friends not to share it further',
              'Tell a parent or counselor immediately',
              'If it is explicit content, this may be illegal - involve adults',
              'Request removal through the platform\'s privacy tools',
            ]}
          />
        </ContentCard>

        <ContentCard type="danger" title="Someone Is Spreading Rumors About You">
          <StepList
            steps={[
              'Do not engage publicly - it often makes things worse',
              'Screenshot the rumors as evidence',
              'Talk to close friends to share the truth privately',
              'Report posts that violate platform guidelines',
              'Consider whether a single, calm correction post makes sense',
            ]}
          />
        </ContentCard>

        <ContentCard type="danger" title="You Are Being Harassed in a Group Chat">
          <StepList
            steps={[
              'Leave the group chat',
              'Screenshot the harassment before leaving',
              'Block the people involved',
              'Report to the platform and, if school-related, to school administration',
              'Create or join supportive group chats with real friends',
            ]}
          />
        </ContentCard>
      </>
    ),
  },
  {
    id: 'resources-support',
    title: 'Resources and Support',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          You do not have to handle cyberbullying alone. Here are resources that can help:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Crisis Resources</h3>
        <ContentCard type="info" title="If You Need Immediate Help">
          <ul className="space-y-2 mt-2">
            <li><strong>Crisis Text Line:</strong> Text HOME to 741741</li>
            <li><strong>National Suicide Prevention Lifeline:</strong> 988 (call or text)</li>
            <li><strong>Trevor Project (LGBTQ+):</strong> 1-866-488-7386</li>
            <li><strong>StopBullying.gov:</strong> Official U.S. government resources</li>
          </ul>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">People Who Can Help</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Parents or guardians</li>
          <li>School counselors</li>
          <li>Teachers you trust</li>
          <li>School administrators</li>
          <li>Older siblings or relatives</li>
          <li>Coaches or youth group leaders</li>
        </ul>

        <ContentCard type="success" title="Remember">
          <ul className="space-y-1 mt-2">
            <li>Cyberbullying is never your fault</li>
            <li>You deserve to be treated with respect</li>
            <li>Speaking up is brave, not weak</li>
            <li>Things will get better</li>
            <li>There are people who care and want to help</li>
          </ul>
        </ContentCard>

        <QuickFact>
          Many people who were cyberbullied as teens go on to become advocates who help others. 
          Your experience, while painful, can become a source of strength and empathy.
        </QuickFact>
      </>
    ),
  },
]

export default function CyberbullyingLesson() {
  return (
    <LessonPage
      title="Cyberbullying & Online Harassment"
      description="Learn to identify, prevent, and respond to cyberbullying. Understand how to protect yourself and support others who are being targeted online."
      icon={Smartphone}
      duration="20 min read"
      difficulty="Beginner"
      sections={sections}
      prevLesson={{ href: '/lessons/social-media', title: 'Social Media Safety' }}
      nextLesson={{ href: '/lessons/malware', title: 'Malware & Viruses' }}
      quizHref="/quizzes/cyberbullying"
    />
  )
}
