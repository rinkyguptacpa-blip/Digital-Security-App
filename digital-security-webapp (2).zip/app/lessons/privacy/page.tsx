import { Shield } from 'lucide-react'
import { LessonPage } from '@/components/lesson-page'
import { ContentCard, ExampleBox, QuickFact, StepList } from '@/components/lesson-content'

const sections = [
  {
    id: 'what-is-personal-data',
    title: 'What Is Personal Data?',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Personal data is any information that can identify you or be used to learn about you. 
          In the digital age, you leave traces of personal data everywhere you go online. 
          Understanding what counts as personal data is the first step to protecting it.
        </p>
        
        <h3 className="text-lg font-semibold mt-6 mb-3">Types of Personal Data</h3>
        
        <ExampleBox title="Direct Identifiers">
          <ul className="space-y-1 mt-2">
            <li>Full name and nickname</li>
            <li>Home address and phone number</li>
            <li>Email address</li>
            <li>Social media handles</li>
            <li>School name and grade</li>
            <li>Photos of your face</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Indirect Identifiers">
          <ul className="space-y-1 mt-2">
            <li>Birthday and age</li>
            <li>Location data from your phone</li>
            <li>Device identifiers</li>
            <li>Browsing history</li>
            <li>Purchase history</li>
            <li>Friends list and connections</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Sensitive Information">
          <ul className="space-y-1 mt-2">
            <li>Passwords and security questions</li>
            <li>Financial information (card numbers, bank accounts)</li>
            <li>Health information</li>
            <li>Private messages and photos</li>
            <li>Political or religious beliefs</li>
          </ul>
        </ExampleBox>

        <QuickFact>
          Even information that seems harmless on its own can become dangerous when combined. 
          Your school name + your grade + your sports team + your first name might be enough 
          for someone to find and identify you.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'digital-footprint',
    title: 'Your Digital Footprint',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Your digital footprint is the trail of data you leave behind whenever you use the 
          internet. Like footprints in sand, some are visible to everyone, while others are 
          hidden but still there.
        </p>

        <ContentCard type="info" title="Active vs Passive Digital Footprint">
          <p className="mb-2"><strong>Active footprint:</strong> Data you intentionally share - social media posts, 
          comments, profile information, photos you upload.</p>
          <p><strong>Passive footprint:</strong> Data collected without you actively sharing it - 
          browsing history, location data, cookies, app usage patterns.</p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">What Contributes to Your Digital Footprint</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Every website you visit</li>
          <li>Every search you make</li>
          <li>Every app you download and use</li>
          <li>Every post, like, comment, and share</li>
          <li>Every photo with location data</li>
          <li>Every online purchase</li>
          <li>Every form you fill out</li>
          <li>Every account you create</li>
        </ul>

        <ContentCard type="warning" title="Your Footprint Can Last Forever">
          <p>
            Even if you delete a post, it might have been screenshot, cached by search engines, 
            or saved on the platform&apos;s servers. The internet never truly forgets. College 
            admissions officers and future employers often search for candidates online.
          </p>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'why-privacy-matters',
    title: 'Why Privacy Matters',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Some people say &quot;I have nothing to hide, so why should I care about privacy?&quot; 
          Here is why everyone should care:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Risks of Poor Privacy</h3>
        
        <ContentCard type="danger" title="Identity Theft">
          <p>
            Criminals can use your personal information to open credit cards in your name, 
            file fake tax returns, or commit crimes while pretending to be you. Cleaning up 
            identity theft can take years.
          </p>
        </ContentCard>

        <ContentCard type="danger" title="Stalking and Harassment">
          <p>
            Oversharing location information or daily routines can make you a target. People 
            have been stalked because they shared their jogging route or check-in location 
            regularly.
          </p>
        </ContentCard>

        <ContentCard type="danger" title="Social Engineering Attacks">
          <p>
            The more scammers know about you, the more convincing their tricks can be. 
            Knowing your pet&apos;s name, your school, or your interests helps them craft 
            personalized phishing attacks.
          </p>
        </ContentCard>

        <ContentCard type="danger" title="Future Consequences">
          <p>
            What you post today might affect college admissions, job opportunities, or 
            relationships years from now. Inappropriate content, controversial opinions, 
            or even just embarrassing moments can resurface at the worst times.
          </p>
        </ContentCard>

        <QuickFact>
          78% of college admissions officers say they have looked at applicants&apos; social media. 
          70% of employers screen candidates on social media before hiring.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'protecting-info-online',
    title: 'Protecting Your Information Online',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Here are practical steps to protect your personal information while still enjoying 
          the internet:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">What to Never Share Online</h3>
        
        <ExampleBox title="Never Share Publicly" good={false}>
          <ul className="space-y-1 mt-2">
            <li>Your home address or directions to your house</li>
            <li>Your phone number</li>
            <li>School name and schedule</li>
            <li>When your house is empty or you are home alone</li>
            <li>Vacation plans while you are away</li>
            <li>Financial information of any kind</li>
            <li>Passwords or password hints</li>
            <li>Government ID numbers</li>
          </ul>
        </ExampleBox>

        <h3 className="text-lg font-semibold mt-6 mb-3">Be Careful With</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Photos that show your school uniform, house number, or license plates</li>
          <li>Check-ins at locations you visit regularly</li>
          <li>Information about your daily routine</li>
          <li>Details about family members</li>
          <li>Your exact birthday (month and day is often enough for security questions)</li>
        </ul>

        <ContentCard type="success" title="The Grandma Test">
          <p>
            Before posting anything, ask yourself: &quot;Would I be comfortable if my grandma 
            saw this? Would I be okay if a stranger saw this? Would I be proud of this 
            in 10 years?&quot; If the answer to any of these is no, do not post it.
          </p>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'privacy-settings',
    title: 'Privacy Settings on Popular Platforms',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Every social media platform has privacy settings, but they are often buried in menus. 
          Here is what to look for:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Essential Settings to Review</h3>
        <StepList
          steps={[
            'Account Privacy: Set to Private/Friends Only instead of Public',
            'Location Services: Disable location tagging on posts',
            'Tag Review: Require approval before you can be tagged in posts',
            'Activity Status: Hide when you are online',
            'Search Visibility: Prevent your profile from appearing in search engines',
            'Third-Party Access: Review which apps have access to your account',
            'Ad Personalization: Limit data used for targeted ads',
            'Download Data: Periodically check what data the platform has about you',
          ]}
        />

        <ContentCard type="info" title="Platform-Specific Tips">
          <p className="mb-2"><strong>Instagram:</strong> Settings → Privacy → Turn on Private Account</p>
          <p className="mb-2"><strong>TikTok:</strong> Settings → Privacy → Turn on Private Account</p>
          <p className="mb-2"><strong>Snapchat:</strong> Settings → Privacy → Turn off Quick Add, set location to Ghost Mode</p>
          <p className="mb-2"><strong>Discord:</strong> Settings → Privacy → Disable DMs from server members</p>
          <p><strong>YouTube:</strong> Settings → Privacy → Control video visibility and comments</p>
        </ContentCard>

        <QuickFact>
          Privacy settings can change when apps update. Set a reminder to review your privacy 
          settings every few months to make sure they have not been reset.
        </QuickFact>
      </>
    ),
  },
  {
    id: 'location-privacy',
    title: 'Location Privacy',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Your location is one of the most sensitive pieces of information. Here is why it 
          matters and how to protect it:
        </p>

        <ContentCard type="danger" title="Dangers of Location Sharing">
          <ul className="space-y-1 mt-2">
            <li>Stalkers can track your movements and find where you live</li>
            <li>Burglars can know when you are away from home</li>
            <li>People can figure out your routine and where to find you</li>
            <li>Location history can reveal private information about your life</li>
          </ul>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">How Your Location Gets Shared</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li><strong>GPS tagging:</strong> Photos often include exact coordinates</li>
          <li><strong>Check-ins:</strong> Posting when you arrive somewhere</li>
          <li><strong>Background apps:</strong> Apps tracking location even when not in use</li>
          <li><strong>Wi-Fi networks:</strong> Connecting to networks reveals general location</li>
          <li><strong>Stories and posts:</strong> Showing landmarks or recognizable places</li>
        </ul>

        <h3 className="text-lg font-semibold mt-6 mb-3">Protecting Your Location</h3>
        <StepList
          steps={[
            'Turn off location services for social media apps',
            'Disable geotagging in your camera settings',
            'Post vacation photos after you return home, not during',
            'Avoid posting from or about your home or school',
            'Use "While Using App" instead of "Always" for location permissions',
            'Regularly review which apps have location access',
            'Turn off Snapchat Maps or set to Ghost Mode',
          ]}
        />

        <ContentCard type="warning" title="Hidden Location Data">
          <p>
            Even without obvious location tags, photos can reveal your location through 
            visible landmarks, store signs, street names, or even the angle of shadows 
            and position of the sun. Be aware of what appears in the background of your photos.
          </p>
        </ContentCard>
      </>
    ),
  },
  {
    id: 'data-collection',
    title: 'How Companies Collect Your Data',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          When you use &quot;free&quot; apps and websites, you are often paying with your data. 
          Understanding how this works helps you make informed decisions.
        </p>

        <ContentCard type="info" title="If It&apos;s Free, You&apos;re the Product">
          <p>
            Companies like Facebook, Google, and TikTok make money by collecting data about 
            you and selling targeted advertising. The more they know about you, the more 
            valuable you are to advertisers.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">What Companies Track</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Everything you search for</li>
          <li>Every website you visit</li>
          <li>How long you spend on each page or video</li>
          <li>What you click on, like, and share</li>
          <li>What you almost bought but did not</li>
          <li>Your location throughout the day</li>
          <li>Your contacts and who you communicate with</li>
          <li>Even things you typed but deleted without posting</li>
        </ul>

        <h3 className="text-lg font-semibold mt-6 mb-3">Cookies and Trackers</h3>
        <ExampleBox title="What Are Cookies?">
          <p>
            Cookies are small files websites store on your device. Some are useful (keeping 
            you logged in), but many are used for tracking. &quot;Third-party cookies&quot; follow 
            you across different websites to build a profile of your interests.
          </p>
        </ExampleBox>

        <h3 className="text-lg font-semibold mt-6 mb-3">Limiting Data Collection</h3>
        <StepList
          steps={[
            'Read app permissions before installing - does a flashlight app really need your contacts?',
            'Deny unnecessary permissions when apps request them',
            'Use privacy-focused browsers like Firefox or Brave',
            'Install browser extensions like uBlock Origin and Privacy Badger',
            'Regularly clear cookies and browsing history',
            'Opt out of personalized ads when given the choice',
            'Use private/incognito mode for sensitive searches',
          ]}
        />
      </>
    ),
  },
  {
    id: 'data-breaches',
    title: 'Data Breaches: When Companies Fail',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Even when you do everything right, companies you trust can have their security 
          breached, exposing your data to hackers.
        </p>

        <ContentCard type="warning" title="What Is a Data Breach?">
          <p>
            A data breach occurs when hackers break into a company&apos;s systems and steal user 
            information. This can include usernames, passwords, email addresses, payment 
            information, and more.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">Notable Data Breaches Affecting Young People</h3>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li><strong>Discord:</strong> Multiple breaches exposing user data</li>
          <li><strong>Epic Games:</strong> Fortnite accounts compromised</li>
          <li><strong>Roblox:</strong> User data exposed through third-party tools</li>
          <li><strong>Various Schools:</strong> Educational platform breaches exposing student info</li>
        </ul>

        <h3 className="text-lg font-semibold mt-6 mb-3">Checking If Your Data Was Breached</h3>
        <ContentCard type="success" title="Use Have I Been Pwned">
          <p>
            Visit haveibeenpwned.com and enter your email address to see if it has appeared 
            in any known data breaches. This legitimate security service is run by a respected 
            security researcher and is safe to use.
          </p>
        </ContentCard>

        <h3 className="text-lg font-semibold mt-6 mb-3">If Your Data Was Breached</h3>
        <StepList
          steps={[
            'Change your password for that service immediately',
            'If you used the same password elsewhere, change those too',
            'Enable two-factor authentication if you have not already',
            'Be alert for phishing attempts using your leaked information',
            'Consider using unique email aliases for different services',
          ]}
        />
      </>
    ),
  },
  {
    id: 'privacy-tools',
    title: 'Privacy Tools and Practices',
    content: (
      <>
        <p className="text-muted-foreground mb-4">
          Here are practical tools and habits to help protect your privacy:
        </p>

        <h3 className="text-lg font-semibold mt-6 mb-3">Recommended Privacy Tools</h3>
        
        <ExampleBox title="Privacy-Focused Browsers">
          <ul className="space-y-1 mt-2">
            <li><strong>Firefox:</strong> Open source with strong privacy features</li>
            <li><strong>Brave:</strong> Blocks ads and trackers by default</li>
            <li><strong>DuckDuckGo Browser:</strong> Privacy-focused mobile browser</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Search Engines That Don&apos;t Track">
          <ul className="space-y-1 mt-2">
            <li><strong>DuckDuckGo:</strong> Does not track searches or build profiles</li>
            <li><strong>Startpage:</strong> Google results without the tracking</li>
          </ul>
        </ExampleBox>

        <ExampleBox title="Browser Extensions">
          <ul className="space-y-1 mt-2">
            <li><strong>uBlock Origin:</strong> Blocks ads and trackers</li>
            <li><strong>Privacy Badger:</strong> Learns to block invisible trackers</li>
            <li><strong>HTTPS Everywhere:</strong> Forces secure connections</li>
          </ul>
        </ExampleBox>

        <h3 className="text-lg font-semibold mt-6 mb-3">Daily Privacy Habits</h3>
        <StepList
          steps={[
            'Think before you share anything online',
            'Use different usernames for different platforms',
            'Create email aliases for signing up for new services',
            'Log out of accounts when using shared devices',
            'Keep apps and devices updated for security patches',
            'Review app permissions regularly',
            'Be skeptical of &quot;free&quot; services and games',
          ]}
        />

        <ContentCard type="success" title="Privacy Is a Mindset">
          <p>
            Protecting your privacy is not about being paranoid or having something to hide. 
            It is about maintaining control over your own information and making conscious 
            choices about what you share and with whom. Start with small steps and build 
            better habits over time.
          </p>
        </ContentCard>
      </>
    ),
  },
]

export default function PrivacyLesson() {
  return (
    <LessonPage
      title="Privacy & Personal Data"
      description="Learn how to protect your personal information online, manage your digital footprint, and understand how companies collect and use your data."
      icon={Shield}
      duration="25 min read"
      difficulty="Beginner"
      sections={sections}
      prevLesson={{ href: '/lessons/deepfakes', title: 'Deepfakes' }}
      nextLesson={{ href: '/lessons/social-media', title: 'Social Media Safety' }}
      quizHref="/quizzes/privacy"
    />
  )
}
