"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, XCircle, ArrowLeft, ArrowRight, RotateCcw, Trophy, Key } from "lucide-react"

const questions = [
  {
    question: "Which of these is the strongest password?",
    options: [
      "password123",
      "MyDogSpot",
      "P@ssw0rd!",
      "7Ks#mP2@xQn9Lv4!"
    ],
    correctIndex: 3,
    explanation: "The strongest password is '7Ks#mP2@xQn9Lv4!' because it's long (16 characters), random, and includes uppercase letters, lowercase letters, numbers, and special characters. The other options are either too short, use common words, or follow predictable patterns."
  },
  {
    question: "Why is using the same password for multiple accounts dangerous?",
    options: [
      "It makes your passwords harder to remember",
      "If one account is hacked, all your accounts using that password are at risk",
      "Websites can detect when you reuse passwords",
      "It slows down your internet connection"
    ],
    correctIndex: 1,
    explanation: "If you use the same password everywhere and one website gets hacked, attackers can use that stolen password to access all your other accounts. This is called 'credential stuffing' and is one of the most common ways accounts get hacked."
  },
  {
    question: "What is two-factor authentication (2FA)?",
    options: [
      "Using two different passwords",
      "Having two people approve your login",
      "A second verification step after your password, like a code sent to your phone",
      "Logging in from two different devices"
    ],
    correctIndex: 2,
    explanation: "Two-factor authentication adds a second layer of security by requiring something you know (your password) AND something you have (like your phone for a verification code). Even if someone steals your password, they can't access your account without the second factor."
  },
  {
    question: "What is the best way to store your passwords?",
    options: [
      "Write them on a sticky note on your monitor",
      "Save them in a document on your desktop called 'passwords.txt'",
      "Use a reputable password manager",
      "Memorize all of them"
    ],
    correctIndex: 2,
    explanation: "A password manager is the safest way to store passwords. It encrypts all your passwords behind one master password, can generate strong unique passwords, and works across all your devices. Writing them down or saving in plain text files is risky, and memorizing unique passwords for every account is practically impossible."
  },
  {
    question: "Your friend asks you to share your Netflix password. What should you do?",
    options: [
      "Share it - friends share everything",
      "Share it but change it to something temporary first",
      "Politely decline - password sharing puts your security at risk",
      "Only share it if they promise not to tell anyone else"
    ],
    correctIndex: 2,
    explanation: "You should politely decline. Once you share a password, you lose control over it. Your friend might accidentally share it, save it insecurely, or their device might be compromised. It also violates most services' terms of use."
  },
  {
    question: "What makes a passphrase better than a traditional password?",
    options: [
      "Passphrases look more professional",
      "Passphrases are longer and easier to remember than random characters",
      "Passphrases are required by law",
      "Passphrases work faster when logging in"
    ],
    correctIndex: 1,
    explanation: "Passphrases like 'correct horse battery staple' are long (making them hard to crack) but made of words (making them easier to remember). Length is one of the most important factors in password security, and passphrases achieve length without being impossible to remember."
  },
  {
    question: "You receive an email saying your password has been compromised in a data breach. What should you do first?",
    options: [
      "Ignore it - it's probably a scam",
      "Click the link in the email to change your password",
      "Go directly to the website (don't click the email link) and change your password",
      "Reply to the email asking for more information"
    ],
    correctIndex: 2,
    explanation: "Never click links in emails about compromised accounts - they could be phishing attempts. Instead, go directly to the website by typing the URL yourself or using a bookmark, then change your password. You can also check haveibeenpwned.com to verify if your email was in a breach."
  },
  {
    question: "Which 2FA method is generally considered the most secure?",
    options: [
      "SMS text messages with codes",
      "Email verification codes",
      "Authenticator apps or hardware security keys",
      "Security questions like 'What's your mother's maiden name?'"
    ],
    correctIndex: 2,
    explanation: "Authenticator apps and hardware security keys are the most secure 2FA methods. SMS can be intercepted through SIM swapping attacks, email accounts can be hacked, and security questions often have guessable answers. Authenticator apps generate codes locally on your device, and hardware keys require physical possession."
  },
  {
    question: "What is a 'brute force attack' on passwords?",
    options: [
      "When hackers physically force you to reveal your password",
      "When computers try every possible password combination until finding the right one",
      "When hackers use social media to guess your password",
      "When websites force you to reset your password"
    ],
    correctIndex: 1,
    explanation: "A brute force attack is when hackers use computers to try every possible combination of characters until they find your password. This is why longer passwords are more secure - a 16-character password takes exponentially longer to crack than an 8-character one."
  },
  {
    question: "Your school requires you to change your password every 90 days. What's the best approach?",
    options: [
      "Just add a number to the end each time (Password1, Password2, etc.)",
      "Use a password manager to generate and store a completely new strong password",
      "Write the new password on your hand so you don't forget",
      "Use the same password but capitalize different letters"
    ],
    correctIndex: 1,
    explanation: "Using a password manager to generate a completely new, strong password is the best approach. Predictable patterns like adding numbers or changing capitalization are easily guessed by hackers. A password manager handles the complexity for you."
  }
]

export default function PasswordsQuizPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>(new Array(questions.length).fill(null))
  const [showResults, setShowResults] = useState(false)
  const [showExplanation, setShowExplanation] = useState(false)

  const handleAnswer = (index: number) => {
    if (selectedAnswers[currentQuestion] !== null) return
    const newAnswers = [...selectedAnswers]
    newAnswers[currentQuestion] = index
    setSelectedAnswers(newAnswers)
    setShowExplanation(true)
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setShowExplanation(false)
    } else {
      setShowResults(true)
    }
  }

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      setShowExplanation(selectedAnswers[currentQuestion - 1] !== null)
    }
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswers(new Array(questions.length).fill(null))
    setShowResults(false)
    setShowExplanation(false)
  }

  const score = selectedAnswers.filter((answer, i) => answer === questions[i].correctIndex).length
  const progress = ((currentQuestion + 1) / questions.length) * 100

  if (showResults) {
    const percentage = Math.round((score / questions.length) * 100)
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 py-16 px-4">
          <div className="container mx-auto max-w-2xl">
            <Card className="text-center">
              <CardHeader>
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Trophy className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="text-3xl">Quiz Complete!</CardTitle>
                <CardDescription>Password Security Quiz Results</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-6xl font-bold text-primary">{percentage}%</div>
                <p className="text-lg text-muted-foreground">
                  You got <span className="font-semibold text-foreground">{score}</span> out of <span className="font-semibold text-foreground">{questions.length}</span> questions correct
                </p>
                
                <div className="py-4">
                  {percentage >= 80 ? (
                    <Badge className="text-lg px-4 py-2 bg-green-500">Excellent! You&apos;re a password pro!</Badge>
                  ) : percentage >= 60 ? (
                    <Badge className="text-lg px-4 py-2 bg-yellow-500">Good job! Keep learning!</Badge>
                  ) : (
                    <Badge className="text-lg px-4 py-2 bg-red-500">Review the lesson and try again!</Badge>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button onClick={resetQuiz} variant="outline">
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Retake Quiz
                  </Button>
                  <Button asChild>
                    <Link href="/lessons/passwords">Review Lesson</Link>
                  </Button>
                  <Button asChild variant="secondary">
                    <Link href="/quizzes">All Quizzes</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  const question = questions[currentQuestion]
  const selectedAnswer = selectedAnswers[currentQuestion]
  const isCorrect = selectedAnswer === question.correctIndex

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 py-8 px-4">
        <div className="container mx-auto max-w-3xl">
          {/* Quiz Header */}
          <div className="mb-8">
            <Link href="/quizzes" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4">
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to Quizzes
            </Link>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Key className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Password Security Quiz</h1>
                <p className="text-sm text-muted-foreground">Question {currentQuestion + 1} of {questions.length}</p>
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question Card */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-xl leading-relaxed">{question.question}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {question.options.map((option, index) => {
                const isSelected = selectedAnswer === index
                const isCorrectOption = index === question.correctIndex
                const showFeedback = selectedAnswer !== null
                
                let buttonClass = "w-full justify-start text-left h-auto py-4 px-4"
                if (showFeedback) {
                  if (isCorrectOption) {
                    buttonClass += " bg-green-500/10 border-green-500 text-green-700 dark:text-green-400"
                  } else if (isSelected && !isCorrect) {
                    buttonClass += " bg-red-500/10 border-red-500 text-red-700 dark:text-red-400"
                  }
                }

                return (
                  <Button
                    key={index}
                    variant="outline"
                    className={buttonClass}
                    onClick={() => handleAnswer(index)}
                    disabled={selectedAnswer !== null}
                  >
                    <span className="w-6 h-6 rounded-full border-2 flex items-center justify-center mr-3 shrink-0 text-sm">
                      {String.fromCharCode(65 + index)}
                    </span>
                    <span className="flex-1">{option}</span>
                    {showFeedback && isCorrectOption && (
                      <CheckCircle className="h-5 w-5 text-green-500 shrink-0 ml-2" />
                    )}
                    {showFeedback && isSelected && !isCorrect && (
                      <XCircle className="h-5 w-5 text-red-500 shrink-0 ml-2" />
                    )}
                  </Button>
                )
              })}
            </CardContent>
          </Card>

          {/* Explanation */}
          {showExplanation && (
            <Card className={`mb-6 ${isCorrect ? "border-green-500/50 bg-green-500/5" : "border-red-500/50 bg-red-500/5"}`}>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  {isCorrect ? (
                    <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <p className={`font-semibold mb-2 ${isCorrect ? "text-green-700 dark:text-green-400" : "text-red-700 dark:text-red-400"}`}>
                      {isCorrect ? "Correct!" : "Not quite right"}
                    </p>
                    <p className="text-muted-foreground">{question.explanation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Navigation */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={prevQuestion}
              disabled={currentQuestion === 0}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
            <Button
              onClick={nextQuestion}
              disabled={selectedAnswer === null}
            >
              {currentQuestion === questions.length - 1 ? "See Results" : "Next"}
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
