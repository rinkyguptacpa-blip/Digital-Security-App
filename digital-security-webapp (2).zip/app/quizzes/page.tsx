import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Key,
  Mail,
  Video,
  Shield,
  Users,
  Heart,
  Bug,
  Gamepad2,
  Footprints,
  Wifi,
  Zap,
  Trophy,
} from "lucide-react"

export const metadata = {
  title: "Quizzes | CyberSafe Academy",
  description: "Test your digital security knowledge with interactive quizzes on passwords, phishing, privacy, and more.",
}

const quizzes = [
  {
    title: "Password Security",
    description: "Test your knowledge about creating and managing strong passwords",
    icon: Key,
    href: "/quizzes/passwords",
    questions: 10,
    difficulty: "Beginner",
    color: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  },
  {
    title: "Phishing & Scams",
    description: "Can you spot fake emails, messages, and websites?",
    icon: Mail,
    href: "/quizzes/phishing",
    questions: 12,
    difficulty: "Intermediate",
    color: "bg-red-500/10 text-red-600 dark:text-red-400",
  },
  {
    title: "Deepfakes & Misinformation",
    description: "Learn to identify AI-generated fake content",
    icon: Video,
    href: "/quizzes/deepfakes",
    questions: 10,
    difficulty: "Advanced",
    color: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
  },
  {
    title: "Privacy Protection",
    description: "How well do you protect your personal information online?",
    icon: Shield,
    href: "/quizzes/privacy",
    questions: 10,
    difficulty: "Intermediate",
    color: "bg-green-500/10 text-green-600 dark:text-green-400",
  },
  {
    title: "Social Media Safety",
    description: "Test your knowledge of safe social media practices",
    icon: Users,
    href: "/quizzes/social-media",
    questions: 10,
    difficulty: "Beginner",
    color: "bg-pink-500/10 text-pink-600 dark:text-pink-400",
  },
  {
    title: "Cyberbullying Awareness",
    description: "Understand how to prevent and respond to cyberbullying",
    icon: Heart,
    href: "/quizzes/cyberbullying",
    questions: 8,
    difficulty: "Beginner",
    color: "bg-orange-500/10 text-orange-600 dark:text-orange-400",
  },
  {
    title: "Malware & Viruses",
    description: "Can you identify and avoid digital threats?",
    icon: Bug,
    href: "/quizzes/malware",
    questions: 10,
    difficulty: "Intermediate",
    color: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
  },
  {
    title: "Gaming Safety",
    description: "Test your knowledge of staying safe while gaming online",
    icon: Gamepad2,
    href: "/quizzes/gaming",
    questions: 10,
    difficulty: "Beginner",
    color: "bg-cyan-500/10 text-cyan-600 dark:text-cyan-400",
  },
]

export default function QuizzesPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 px-4 bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center max-w-3xl mx-auto">
              <Badge variant="secondary" className="mb-4">
                <Trophy className="h-3 w-3 mr-1" />
                Interactive Learning
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
                Test Your Knowledge
              </h1>
              <p className="text-lg text-muted-foreground text-pretty">
                Put your digital security skills to the test with our interactive quizzes. 
                Track your progress and earn badges as you master each topic.
              </p>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-8 px-4 border-b border-border">
          <div className="container mx-auto max-w-6xl">
            <div className="flex flex-wrap justify-center gap-8 md:gap-16">
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">8</p>
                <p className="text-sm text-muted-foreground">Topic Quizzes</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">80+</p>
                <p className="text-sm text-muted-foreground">Questions</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">3</p>
                <p className="text-sm text-muted-foreground">Difficulty Levels</p>
              </div>
            </div>
          </div>
        </section>

        {/* Quizzes Grid */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {quizzes.map((quiz) => (
                <Card key={quiz.title} className="group hover:shadow-lg transition-all duration-300 border-border">
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg ${quiz.color} flex items-center justify-center mb-3`}>
                      <quiz.icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="text-xl">{quiz.title}</CardTitle>
                    <CardDescription>{quiz.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm text-muted-foreground">{quiz.questions} questions</span>
                      <Badge variant={quiz.difficulty === "Beginner" ? "secondary" : quiz.difficulty === "Intermediate" ? "outline" : "default"}>
                        {quiz.difficulty}
                      </Badge>
                    </div>
                    <Button asChild className="w-full">
                      <Link href={quiz.href}>Start Quiz</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Master Quiz CTA */}
        <section className="py-16 px-4 bg-muted/50">
          <div className="container mx-auto max-w-4xl">
            <Card className="bg-primary text-primary-foreground">
              <CardContent className="p-8 md:p-12">
                <div className="flex flex-col md:flex-row items-center gap-6">
                  <div className="w-16 h-16 bg-primary-foreground/10 rounded-full flex items-center justify-center shrink-0">
                    <Zap className="h-8 w-8" />
                  </div>
                  <div className="flex-1 text-center md:text-left">
                    <h2 className="text-2xl font-bold mb-2">Master Quiz Challenge</h2>
                    <p className="text-primary-foreground/80">
                      Ready to prove you are a digital security expert? Take the comprehensive master quiz 
                      covering all topics. Score 80% or higher to earn your CyberSafe Certificate!
                    </p>
                  </div>
                  <Button variant="secondary" size="lg" asChild>
                    <Link href="/quizzes/master">Take Challenge</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Tips Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl">
            <h2 className="text-2xl font-bold text-center mb-8">Quiz Tips</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">1</span>
                </div>
                <h3 className="font-semibold mb-2">Read the Lessons</h3>
                <p className="text-sm text-muted-foreground">
                  Review the lesson content before taking quizzes for better scores
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">2</span>
                </div>
                <h3 className="font-semibold mb-2">Take Your Time</h3>
                <p className="text-sm text-muted-foreground">
                  There are no time limits - read each question carefully
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">3</span>
                </div>
                <h3 className="font-semibold mb-2">Learn from Mistakes</h3>
                <p className="text-sm text-muted-foreground">
                  Review explanations for wrong answers to reinforce learning
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
