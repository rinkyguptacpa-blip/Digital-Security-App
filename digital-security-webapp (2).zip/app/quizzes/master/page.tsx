import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Construction, Zap } from "lucide-react"

export const metadata = {
  title: "Master Quiz Challenge | CyberSafe Academy",
  description: "Test your knowledge across all digital security topics in this comprehensive challenge.",
}

export default function MasterQuizPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 py-16 px-4">
        <div className="container mx-auto max-w-2xl">
          <Card className="text-center">
            <CardHeader>
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="h-10 w-10 text-primary" />
              </div>
              <CardTitle className="text-3xl">Master Quiz Challenge</CardTitle>
              <CardDescription>The ultimate digital security test</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-center gap-2">
                <Construction className="h-5 w-5 text-muted-foreground" />
                <span className="text-muted-foreground font-medium">Coming Soon!</span>
              </div>
              <p className="text-muted-foreground">
                The Master Quiz Challenge combines questions from all topics into one comprehensive test. 
                Score 80% or higher to earn your CyberSafe Certificate!
              </p>
              <p className="text-sm text-muted-foreground">
                Complete individual topic quizzes first to prepare for the challenge.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="outline">
                  <Link href="/quizzes">Practice Topic Quizzes</Link>
                </Button>
                <Button asChild>
                  <Link href="/lessons">Review All Lessons</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}
