"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, XCircle, ArrowLeft, ArrowRight, RotateCcw, Trophy, Mail } from "lucide-react"

const questions = [
  {
    question: "You receive an email from 'Amazon' saying your account will be suspended unless you click a link to verify your information. What's the first thing you should check?",
    options: [
      "Whether the email has the Amazon logo",
      "The sender's email address to see if it's actually from Amazon",
      "If the email mentions your name",
      "How urgent the message sounds"
    ],
    correctIndex: 1,
    explanation: "Always check the sender's email address first. Legitimate Amazon emails come from @amazon.com domains. Phishing emails often use fake addresses like 'amazon-security@mail.com' or 'support@amaz0n.net'. Logos can be easily copied, and scammers often include your name to seem legitimate."
  },
  {
    question: "Which of these URLs is most likely a phishing attempt?",
    options: [
      "https://www.paypal.com/account",
      "https://paypal-secure.verify-account.com",
      "https://www.paypal.com/signin",
      "https://paypal.com/security"
    ],
    correctIndex: 1,
    explanation: "The URL 'paypal-secure.verify-account.com' is a phishing attempt. The actual domain is 'verify-account.com', not PayPal. Scammers add legitimate company names to make fake URLs look real. Always look at what comes RIGHT BEFORE the .com (or .org, .net, etc.) - that's the real domain."
  },
  {
    question: "A text message says you've won a $500 gift card and need to click a link to claim it. You never entered any contest. What should you do?",
    options: [
      "Click to see if it's real - you might have won something",
      "Reply 'STOP' to unsubscribe from future messages",
      "Delete the message without clicking anything",
      "Forward it to friends so they can win too"
    ],
    correctIndex: 2,
    explanation: "Delete suspicious messages without interacting with them. If you didn't enter a contest, you didn't win one. Clicking links can install malware or lead to phishing sites. Even replying 'STOP' confirms your number is active to scammers."
  },
  {
    question: "Your friend sends you a DM on Instagram with just a link and the message 'OMG is this you?!?' What's likely happening?",
    options: [
      "Your friend found an embarrassing photo of you",
      "Your friend's account may have been hacked and is sending scam links",
      "It's probably a funny meme they want to share",
      "You should click it quickly before the link expires"
    ],
    correctIndex: 1,
    explanation: "Messages like 'OMG is this you?!' with suspicious links are a common sign of a hacked account. Scammers use this tactic because curiosity makes people click. Contact your friend through another method (text, call) to verify if they actually sent it before clicking anything."
  },
  {
    question: "What is 'spear phishing'?",
    options: [
      "Phishing that uses images of fish",
      "Targeted phishing attacks using personal information about the victim",
      "Phishing attempts sent to millions of people at once",
      "Phishing that only happens on fishing-related websites"
    ],
    correctIndex: 1,
    explanation: "Spear phishing is a targeted attack where scammers research you specifically - using your name, school, interests, or other personal details to make the scam more believable. Unlike regular phishing sent to millions, spear phishing is personalized and harder to detect."
  },
  {
    question: "You get an email from your 'principal' asking you to buy gift cards for a school emergency. The email looks official. What should you do?",
    options: [
      "Buy the gift cards - it's from your principal",
      "Reply asking for more details",
      "Verify through another channel - call the school office directly",
      "Forward it to other students to help out"
    ],
    correctIndex: 2,
    explanation: "This is a common scam called 'CEO fraud' or 'authority impersonation.' Scammers impersonate authority figures to pressure victims. Always verify unusual requests through a separate communication channel - call the school office directly using a number you already have, not one from the suspicious email."
  },
  {
    question: "A website asks you to enter your password to 'verify your identity' before showing you content. The website URL is correct. Is this safe?",
    options: [
      "Yes, if the URL is correct it must be safe",
      "Not necessarily - even correct-looking URLs can be fake, and legitimate sites rarely ask this",
      "Only if the site has a padlock icon",
      "Yes, if your browser doesn't show a warning"
    ],
    correctIndex: 1,
    explanation: "Legitimate websites rarely ask you to re-enter your password just to view content. Even if a URL looks correct, it could be a homograph attack (using similar-looking characters) or a compromised legitimate site. Be suspicious of any unexpected password requests."
  },
  {
    question: "What's a 'pretexting' attack?",
    options: [
      "When scammers send texts before calling you",
      "When attackers create a fake scenario or identity to manipulate you",
      "When phishing emails have pre-written text templates",
      "When hackers test their attacks before launching them"
    ],
    correctIndex: 1,
    explanation: "Pretexting is when scammers invent a false scenario to gain your trust. For example, someone might call pretending to be IT support, a bank representative, or a survey company. They use this fake 'pretext' to trick you into revealing information or taking actions you normally wouldn't."
  },
  {
    question: "Which of these is a red flag that an email might be a phishing attempt?",
    options: [
      "The email is addressed to 'Dear Customer' instead of your name",
      "The email has no spelling errors",
      "The email came during business hours",
      "The email has a professional signature"
    ],
    correctIndex: 0,
    explanation: "Generic greetings like 'Dear Customer' or 'Dear User' are red flags - legitimate companies usually know your name. However, modern phishing can be sophisticated, so this alone doesn't guarantee safety. Always check multiple factors: sender address, URL destinations, and whether the request makes sense."
  },
  {
    question: "A pop-up on a website says your computer has a virus and you should call a number immediately. What should you do?",
    options: [
      "Call the number - viruses are serious",
      "Download the recommended antivirus software from the pop-up",
      "Close the browser tab or window - this is a 'tech support scam'",
      "Give them remote access so they can fix it"
    ],
    correctIndex: 2,
    explanation: "This is a 'tech support scam.' Legitimate antivirus software doesn't use browser pop-ups demanding you call phone numbers. Close the browser tab (Ctrl+W or Cmd+W). If the pop-up won't close, use Task Manager or Force Quit to close the browser. Never call numbers from pop-ups or give remote access."
  },
  {
    question: "You click a link and the website asks you to download a 'security update' to view the content. What should you do?",
    options: [
      "Download it if you trust the original link source",
      "Download it only if your browser says it's safe",
      "Do not download - legitimate websites don't require downloads to view content",
      "Download it to a USB drive first to be safe"
    ],
    correctIndex: 2,
    explanation: "Legitimate websites never require you to download software to view their content. This is a common malware distribution trick. Close the website immediately and run an antivirus scan. Software updates should only come from official sources, not random website pop-ups."
  },
  {
    question: "Someone online is offering to send you money if you first send them a small 'processing fee.' This is most likely:",
    options: [
      "A legitimate offer if they seem trustworthy",
      "Safe if they provide official-looking documents",
      "An advance fee fraud scam",
      "Okay if the amount they're offering is large enough"
    ],
    correctIndex: 2,
    explanation: "This is classic 'advance fee fraud' (also known as 419 scams). Scammers promise large sums of money but require you to pay fees first. The promised money never arrives, and they'll keep asking for more fees. Legitimate transactions don't require you to pay to receive money."
  }
]

export default function PhishingQuizPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>(new Array(questions.length).fill(null))
  const [showResults, setShowResults] = useState(false)
  const [showExplanation, setShowExplanation] = useState(false)

  const handleAnswer = (index: number) => {
    if (selectedAnswers[currentQuestion] !== null) return
    const newAnswers = [...selectedAnswers]
    newAnswers[currentQuestion] = index
    setSelectedAnswers(newAnswers)
    setShowExplanation(true)
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setShowExplanation(false)
    } else {
      setShowResults(true)
    }
  }

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      setShowExplanation(selectedAnswers[currentQuestion - 1] !== null)
    }
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswers(new Array(questions.length).fill(null))
    setShowResults(false)
    setShowExplanation(false)
  }

  const score = selectedAnswers.filter((answer, i) => answer === questions[i].correctIndex).length
  const progress = ((currentQuestion + 1) / questions.length) * 100

  if (showResults) {
    const percentage = Math.round((score / questions.length) * 100)
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 py-16 px-4">
          <div className="container mx-auto max-w-2xl">
            <Card className="text-center">
              <CardHeader>
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Trophy className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="text-3xl">Quiz Complete!</CardTitle>
                <CardDescription>Phishing & Scams Quiz Results</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-6xl font-bold text-primary">{percentage}%</div>
                <p className="text-lg text-muted-foreground">
                  You got <span className="font-semibold text-foreground">{score}</span> out of <span className="font-semibold text-foreground">{questions.length}</span> questions correct
                </p>
                
                <div className="py-4">
                  {percentage >= 80 ? (
                    <Badge className="text-lg px-4 py-2 bg-green-500">Excellent! You&apos;re a phishing detection expert!</Badge>
                  ) : percentage >= 60 ? (
                    <Badge className="text-lg px-4 py-2 bg-yellow-500">Good job! Keep practicing!</Badge>
                  ) : (
                    <Badge className="text-lg px-4 py-2 bg-red-500">Review the lesson and try again!</Badge>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button onClick={resetQuiz} variant="outline">
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Retake Quiz
                  </Button>
                  <Button asChild>
                    <Link href="/lessons/phishing">Review Lesson</Link>
                  </Button>
                  <Button asChild variant="secondary">
                    <Link href="/quizzes">All Quizzes</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  const question = questions[currentQuestion]
  const selectedAnswer = selectedAnswers[currentQuestion]
  const isCorrect = selectedAnswer === question.correctIndex

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 py-8 px-4">
        <div className="container mx-auto max-w-3xl">
          {/* Quiz Header */}
          <div className="mb-8">
            <Link href="/quizzes" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4">
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to Quizzes
            </Link>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                <Mail className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Phishing & Scams Quiz</h1>
                <p className="text-sm text-muted-foreground">Question {currentQuestion + 1} of {questions.length}</p>
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question Card */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-xl leading-relaxed">{question.question}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {question.options.map((option, index) => {
                const isSelected = selectedAnswer === index
                const isCorrectOption = index === question.correctIndex
                const showFeedback = selectedAnswer !== null
                
                let buttonClass = "w-full justify-start text-left h-auto py-4 px-4"
                if (showFeedback) {
                  if (isCorrectOption) {
                    buttonClass += " bg-green-500/10 border-green-500 text-green-700 dark:text-green-400"
                  } else if (isSelected && !isCorrect) {
                    buttonClass += " bg-red-500/10 border-red-500 text-red-700 dark:text-red-400"
                  }
                }

                return (
                  <Button
                    key={index}
                    variant="outline"
                    className={buttonClass}
                    onClick={() => handleAnswer(index)}
                    disabled={selectedAnswer !== null}
                  >
                    <span className="w-6 h-6 rounded-full border-2 flex items-center justify-center mr-3 shrink-0 text-sm">
                      {String.fromCharCode(65 + index)}
                    </span>
                    <span className="flex-1">{option}</span>
                    {showFeedback && isCorrectOption && (
                      <CheckCircle className="h-5 w-5 text-green-500 shrink-0 ml-2" />
                    )}
                    {showFeedback && isSelected && !isCorrect && (
                      <XCircle className="h-5 w-5 text-red-500 shrink-0 ml-2" />
                    )}
                  </Button>
                )
              })}
            </CardContent>
          </Card>

          {/* Explanation */}
          {showExplanation && (
            <Card className={`mb-6 ${isCorrect ? "border-green-500/50 bg-green-500/5" : "border-red-500/50 bg-red-500/5"}`}>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  {isCorrect ? (
                    <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <p className={`font-semibold mb-2 ${isCorrect ? "text-green-700 dark:text-green-400" : "text-red-700 dark:text-red-400"}`}>
                      {isCorrect ? "Correct!" : "Not quite right"}
                    </p>
                    <p className="text-muted-foreground">{question.explanation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Navigation */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={prevQuestion}
              disabled={currentQuestion === 0}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
            <Button
              onClick={nextQuestion}
              disabled={selectedAnswer === null}
            >
              {currentQuestion === questions.length - 1 ? "See Results" : "Next"}
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
