import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Construction } from "lucide-react"

export const metadata = {
  title: "Quiz Coming Soon | CyberSafe Academy",
  description: "This quiz is coming soon. Check back later!",
}

export default function QuizComingSoon() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 py-16 px-4">
        <div className="container mx-auto max-w-2xl">
          <Card className="text-center">
            <CardHeader>
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Construction className="h-10 w-10 text-primary" />
              </div>
              <CardTitle className="text-3xl">Coming Soon!</CardTitle>
              <CardDescription>This quiz is currently being developed</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-muted-foreground">
                We&apos;re working hard to create engaging quiz questions for this topic. 
                In the meantime, check out the lesson to learn about this subject!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="outline">
                  <Link href="/quizzes">Browse Other Quizzes</Link>
                </Button>
                <Button asChild>
                  <Link href="/lessons/gaming-safety">Gaming Safety Lesson</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}
