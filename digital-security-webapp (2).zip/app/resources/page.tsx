import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  ExternalLink,
  BookOpen,
  Shield,
  Gamepad2,
  MessageCircle,
  Phone,
  Globe,
  Users,
  AlertTriangle,
  Heart,
} from "lucide-react"

export const metadata = {
  title: "Resources | CyberSafe Academy",
  description: "Helpful resources, tools, and organizations for digital security and online safety.",
}

const toolsAndResources = [
  {
    title: "Have I Been Pwned",
    description: "Check if your email or phone number has been involved in a data breach",
    url: "https://haveibeenpwned.com",
    category: "Security Check",
  },
  {
    title: "Google Password Checkup",
    description: "Check if your saved passwords have been compromised",
    url: "https://passwords.google.com/checkup",
    category: "Password Security",
  },
  {
    title: "1Password",
    description: "Popular password manager for individuals and families",
    url: "https://1password.com",
    category: "Password Manager",
  },
  {
    title: "Bitwarden",
    description: "Free, open-source password manager",
    url: "https://bitwarden.com",
    category: "Password Manager",
  },
  {
    title: "DuckDuckGo",
    description: "Privacy-focused search engine that doesn't track you",
    url: "https://duckduckgo.com",
    category: "Privacy",
  },
  {
    title: "VirusTotal",
    description: "Analyze suspicious files and URLs for malware",
    url: "https://www.virustotal.com",
    category: "Security Check",
  },
]

const helpOrganizations = [
  {
    title: "Cyberbullying Research Center",
    description: "Research and resources about cyberbullying prevention and response",
    url: "https://cyberbullying.org",
    icon: Heart,
  },
  {
    title: "StopBullying.gov",
    description: "U.S. government resource for bullying and cyberbullying prevention",
    url: "https://www.stopbullying.gov",
    icon: Shield,
  },
  {
    title: "Internet Safety 101",
    description: "Educational resources for parents and students about online safety",
    url: "https://internetsafety101.org",
    icon: BookOpen,
  },
  {
    title: "National Cyber Security Alliance",
    description: "Promotes cybersecurity awareness and education",
    url: "https://staysafeonline.org",
    icon: Globe,
  },
  {
    title: "Common Sense Media",
    description: "Reviews and resources for age-appropriate media and technology use",
    url: "https://www.commonsensemedia.org",
    icon: Users,
  },
  {
    title: "FBI Internet Crime Complaint Center",
    description: "Report internet crimes and learn about current scams",
    url: "https://www.ic3.gov",
    icon: AlertTriangle,
  },
]

const emergencyContacts = [
  {
    title: "Crisis Text Line",
    description: "Text HOME to 741741 for free, 24/7 crisis support",
    contact: "Text HOME to 741741",
    icon: MessageCircle,
  },
  {
    title: "National Suicide Prevention Lifeline",
    description: "Free, confidential support for people in distress",
    contact: "988 or 1-800-273-8255",
    icon: Phone,
  },
  {
    title: "Childhelp National Child Abuse Hotline",
    description: "24/7 support for children and adults affected by abuse",
    contact: "1-800-422-4453",
    icon: Phone,
  },
  {
    title: "CyberTipline",
    description: "Report online exploitation of children",
    contact: "CyberTipline.org",
    icon: AlertTriangle,
  },
]

const gamingResources = [
  {
    title: "Family Online Safety Institute",
    description: "Tools and resources for safe gaming and social media use",
    url: "https://www.fosi.org",
  },
  {
    title: "ESRB Ratings",
    description: "Understand game ratings and content descriptions",
    url: "https://www.esrb.org",
  },
  {
    title: "Discord Safety",
    description: "Official Discord safety resources and parent guides",
    url: "https://discord.com/safety",
  },
  {
    title: "Roblox Safety",
    description: "Parent's guide to Roblox safety features",
    url: "https://corp.roblox.com/parents",
  },
]

export default function ResourcesPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 px-4 bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center max-w-3xl mx-auto">
              <Badge variant="secondary" className="mb-4">
                <BookOpen className="h-3 w-3 mr-1" />
                Helpful Resources
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
                Resources & Tools
              </h1>
              <p className="text-lg text-muted-foreground text-pretty">
                Curated tools, organizations, and resources to help you stay safe online. 
                These resources are trusted by cybersecurity experts and educators.
              </p>
            </div>
          </div>
        </section>

        {/* Security Tools */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <h2 className="text-2xl font-bold mb-2">Security Tools & Resources</h2>
            <p className="text-muted-foreground mb-8">Free tools to check your security and protect yourself online</p>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {toolsAndResources.map((tool) => (
                <Card key={tool.title} className="group hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-lg">{tool.title}</CardTitle>
                      <Badge variant="outline" className="text-xs shrink-0 ml-2">{tool.category}</Badge>
                    </div>
                    <CardDescription>{tool.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild variant="outline" className="w-full">
                      <a href={tool.url} target="_blank" rel="noopener noreferrer">
                        Visit Website
                        <ExternalLink className="h-4 w-4 ml-2" />
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Help Organizations */}
        <section className="py-16 px-4 bg-muted/30">
          <div className="container mx-auto max-w-6xl">
            <h2 className="text-2xl font-bold mb-2">Safety Organizations</h2>
            <p className="text-muted-foreground mb-8">Trusted organizations focused on online safety and education</p>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {helpOrganizations.map((org) => (
                <Card key={org.title} className="group hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <org.icon className="h-5 w-5 text-primary" />
                      </div>
                      <CardTitle className="text-lg">{org.title}</CardTitle>
                    </div>
                    <CardDescription className="mt-2">{org.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild variant="outline" className="w-full">
                      <a href={org.url} target="_blank" rel="noopener noreferrer">
                        Learn More
                        <ExternalLink className="h-4 w-4 ml-2" />
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Emergency Contacts */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-2 text-red-700 dark:text-red-400">Need Help? Emergency Contacts</h2>
              <p className="text-muted-foreground mb-8">If you or someone you know needs immediate help, these resources are available 24/7</p>
              <div className="grid md:grid-cols-2 gap-6">
                {emergencyContacts.map((contact) => (
                  <Card key={contact.title} className="border-red-500/20">
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center shrink-0">
                          <contact.icon className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold mb-1">{contact.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{contact.description}</p>
                          <p className="font-mono text-sm font-semibold text-red-700 dark:text-red-400">{contact.contact}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Gaming Resources */}
        <section className="py-16 px-4 bg-muted/30">
          <div className="container mx-auto max-w-6xl">
            <div className="flex items-center gap-3 mb-2">
              <Gamepad2 className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold">Gaming Safety Resources</h2>
            </div>
            <p className="text-muted-foreground mb-8">Resources specifically for safe gaming and platform-specific guides</p>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {gamingResources.map((resource) => (
                <Card key={resource.title} className="group hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <CardTitle className="text-base">{resource.title}</CardTitle>
                    <CardDescription className="text-sm">{resource.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild variant="outline" size="sm" className="w-full">
                      <a href={resource.url} target="_blank" rel="noopener noreferrer">
                        Visit
                        <ExternalLink className="h-3 w-3 ml-2" />
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* For Educators Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl">
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-8 md:p-12">
                <div className="text-center">
                  <h2 className="text-2xl font-bold mb-4">For Parents & Educators</h2>
                  <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                    CyberSafe Academy is designed to be used in classrooms and at home. 
                    All content is age-appropriate for students ages 10-18 and can be adapted 
                    for different grade levels.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button asChild>
                      <Link href="/lessons">Browse All Lessons</Link>
                    </Button>
                    <Button asChild variant="outline">
                      <Link href="/quizzes">View Quizzes</Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
