import Link from 'next/link'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Shield, 
  Lock, 
  Eye, 
  AlertTriangle, 
  Users, 
  Smartphone,
  BookOpen,
  Trophy,
  Gamepad2,
  Bug,
  ArrowRight,
  CheckCircle
} from 'lucide-react'

const lessons = [
  {
    href: '/lessons/passwords',
    title: 'Passwords & Authentication',
    description: 'Learn to create strong passwords and use two-factor authentication to protect your accounts.',
    icon: Lock,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
  {
    href: '/lessons/phishing',
    title: 'Phishing & Scams',
    description: 'Recognize fake emails, messages, and websites designed to steal your information.',
    icon: AlertTriangle,
    color: 'text-warning',
    bgColor: 'bg-warning/10',
  },
  {
    href: '/lessons/deepfakes',
    title: 'Deepfakes & Misinformation',
    description: 'Understand AI-generated fake content and learn to verify what you see online.',
    icon: Eye,
    color: 'text-accent',
    bgColor: 'bg-accent/10',
  },
  {
    href: '/lessons/privacy',
    title: 'Privacy & Personal Data',
    description: 'Protect your personal information and control your digital footprint.',
    icon: Shield,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
  {
    href: '/lessons/social-media',
    title: 'Social Media Safety',
    description: 'Navigate social platforms safely and manage your online presence.',
    icon: Users,
    color: 'text-accent',
    bgColor: 'bg-accent/10',
  },
  {
    href: '/lessons/cyberbullying',
    title: 'Cyberbullying & Harassment',
    description: 'Identify, prevent, and respond to online bullying and harassment.',
    icon: Smartphone,
    color: 'text-destructive',
    bgColor: 'bg-destructive/10',
  },
  {
    href: '/lessons/malware',
    title: 'Malware & Viruses',
    description: 'Learn about different types of malicious software and how to protect your devices.',
    icon: Bug,
    color: 'text-warning',
    bgColor: 'bg-warning/10',
  },
  {
    href: '/lessons/gaming-safety',
    title: 'Gaming & Online Safety',
    description: 'Stay safe while gaming online and protect yourself from gaming-related threats.',
    icon: Gamepad2,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
]

const features = [
  {
    title: 'Interactive Lessons',
    description: 'Learn through engaging content with real-world examples that relate to your daily digital life.',
    icon: BookOpen,
  },
  {
    title: 'Test Your Knowledge',
    description: 'Take quizzes after each lesson to reinforce what you learned and track your progress.',
    icon: Trophy,
  },
  {
    title: 'Practical Skills',
    description: 'Gain hands-on skills you can immediately apply to protect yourself and your family online.',
    icon: CheckCircle,
  },
]

const stats = [
  { value: '8', label: 'Lessons' },
  { value: '40+', label: 'Topics' },
  { value: '100+', label: 'Examples' },
  { value: '8', label: 'Quizzes' },
]

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden px-4 py-20 sm:px-6 lg:px-8">
          <div className="absolute inset-0 -z-10">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />
          </div>
          
          <div className="mx-auto max-w-7xl">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-2 text-sm">
                <Shield className="h-4 w-4 text-primary" />
                <span>Free Digital Security Education for Students</span>
              </div>
              
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
                <span className="gradient-text">Stay Safe</span> in the Digital World
              </h1>
              
              <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
                Learn essential cybersecurity skills to protect yourself online. 
                From strong passwords to spotting scams, our interactive lessons prepare 
                students aged 10-18 for real-world digital challenges.
              </p>
              
              <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Button asChild size="lg" className="glow-primary">
                  <Link href="/lessons/passwords">
                    Start Learning <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/quizzes">Take a Quiz</Link>
                </Button>
              </div>
            </div>
            
            {/* Stats */}
            <div className="mt-16 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {stats.map((stat) => (
                <div key={stat.label} className="rounded-lg border border-border bg-card p-6 text-center">
                  <div className="text-3xl font-bold text-primary">{stat.value}</div>
                  <div className="mt-1 text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="border-y border-border bg-card/50 px-4 py-16 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="text-center">
              <h2 className="text-2xl font-bold sm:text-3xl">Why Learn Digital Security?</h2>
              <p className="mt-4 text-muted-foreground">
                Every day, young people face online threats. Our curriculum gives you the knowledge to stay safe.
              </p>
            </div>
            
            <div className="mt-12 grid gap-8 md:grid-cols-3">
              {features.map((feature) => (
                <div key={feature.title} className="flex flex-col items-center text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                    <feature.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mt-4 text-lg font-semibold">{feature.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Lessons Section */}
        <section className="px-4 py-16 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="text-center">
              <h2 className="text-2xl font-bold sm:text-3xl">Lessons</h2>
              <p className="mt-4 text-muted-foreground">
                Explore our comprehensive digital security curriculum designed for students.
              </p>
            </div>
            
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {lessons.map((lesson) => (
                <Link key={lesson.href} href={lesson.href} className="group">
                  <Card className="h-full transition-all duration-200 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5">
                    <CardHeader>
                      <div className={`mb-2 flex h-12 w-12 items-center justify-center rounded-lg ${lesson.bgColor}`}>
                        <lesson.icon className={`h-6 w-6 ${lesson.color}`} />
                      </div>
                      <CardTitle className="text-lg group-hover:text-primary">{lesson.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-sm">{lesson.description}</CardDescription>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Quizzes CTA Section */}
        <section className="border-t border-border bg-card/50 px-4 py-16 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="flex flex-col items-center justify-between gap-8 rounded-xl border border-border bg-card p-8 md:flex-row md:p-12">
              <div className="text-center md:text-left">
                <h2 className="text-2xl font-bold sm:text-3xl">Test Your Knowledge</h2>
                <p className="mt-4 max-w-xl text-muted-foreground">
                  Ready to see how much you have learned? Take our interactive quizzes to test 
                  your digital security knowledge and identify areas for improvement.
                </p>
              </div>
              <Button asChild size="lg" className="shrink-0">
                <Link href="/quizzes">
                  <Trophy className="mr-2 h-5 w-5" />
                  Take Quizzes
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* About Preview Section */}
        <section className="px-4 py-16 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-2xl font-bold sm:text-3xl">About CyberSafe Academy</h2>
              <p className="mt-6 text-muted-foreground leading-relaxed">
                CyberSafe Academy was created to address the growing need for digital security education 
                among young people. Our mission is to empower students with the knowledge and skills 
                they need to navigate the online world safely and confidently.
              </p>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                The digital world is constantly evolving, and so are the threats. Our curriculum 
                covers real-world dangers that students encounter daily, from social media scams 
                to gaming-related threats, making it practical and immediately applicable.
              </p>
              <Button asChild variant="outline" className="mt-8">
                <Link href="/about">Learn More About Us</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}
