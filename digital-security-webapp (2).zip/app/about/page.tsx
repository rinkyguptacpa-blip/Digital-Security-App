import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Shield,
  Target,
  Users,
  BookOpen,
  CheckCircle,
  GraduationCap,
  Heart,
  Lightbulb,
} from "lucide-react"

export const metadata = {
  title: "About | CyberSafe Academy",
  description: "Learn about CyberSafe Academy's mission to teach digital security to students ages 10-18.",
}

const values = [
  {
    icon: Shield,
    title: "Safety First",
    description: "We prioritize practical, actionable advice that keeps students safe in their daily digital lives.",
  },
  {
    icon: Lightbulb,
    title: "Age-Appropriate",
    description: "All content is designed for students ages 10-18, using language and examples they can relate to.",
  },
  {
    icon: Heart,
    title: "Empathy-Driven",
    description: "We understand the challenges young people face online and approach topics with compassion.",
  },
  {
    icon: Target,
    title: "Practical Focus",
    description: "Every lesson includes real-world examples and actionable steps students can implement immediately.",
  },
]

const features = [
  "10 comprehensive lessons covering essential digital security topics",
  "Interactive quizzes to test knowledge and reinforce learning",
  "Real-world examples and scenarios students can relate to",
  "Age-appropriate content for middle and high school students",
  "Curated resources and tools for continued learning",
  "Regular updates to address new threats and technologies",
]

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 px-4 bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center max-w-3xl mx-auto">
              <Badge variant="secondary" className="mb-4">
                <GraduationCap className="h-3 w-3 mr-1" />
                About Us
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
                Empowering Students to Navigate the Digital World Safely
              </h1>
              <p className="text-lg text-muted-foreground text-pretty">
                CyberSafe Academy is a free educational platform dedicated to teaching digital security 
                and online safety to students ages 10-18.
              </p>
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  In today&apos;s digital world, young people face unprecedented challenges online - from 
                  sophisticated phishing attacks and deepfakes to cyberbullying and privacy invasions. 
                  Traditional education often fails to keep pace with these rapidly evolving threats.
                </p>
                <p className="text-lg text-muted-foreground mb-6">
                  CyberSafe Academy bridges this gap by providing comprehensive, engaging, and practical 
                  digital security education specifically designed for students. Our goal is to empower 
                  young people with the knowledge and skills they need to protect themselves online.
                </p>
                <p className="text-lg text-muted-foreground">
                  We believe that digital literacy is just as important as reading and math. Every 
                  student deserves access to high-quality cybersecurity education, regardless of their 
                  school&apos;s resources.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-6">
                {values.map((value) => (
                  <Card key={value.title} className="text-center">
                    <CardContent className="pt-6">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                        <value.icon className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="font-semibold mb-2">{value.title}</h3>
                      <p className="text-sm text-muted-foreground">{value.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* What We Offer */}
        <section className="py-16 px-4 bg-muted/30">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl font-bold mb-4">What We Offer</h2>
              <p className="text-lg text-muted-foreground">
                A complete digital security curriculum designed for today&apos;s students
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                  <span className="text-foreground">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Topics Covered */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl font-bold mb-4">Topics We Cover</h2>
              <p className="text-lg text-muted-foreground">
                Comprehensive curriculum addressing real-world digital threats
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Password Security</CardTitle>
                  <CardDescription>Creating strong passwords and using 2FA</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Phishing & Scams</CardTitle>
                  <CardDescription>Recognizing and avoiding online fraud</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Deepfakes & AI</CardTitle>
                  <CardDescription>Spotting AI-generated fake content</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Privacy Protection</CardTitle>
                  <CardDescription>Controlling your personal information</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Social Media Safety</CardTitle>
                  <CardDescription>Navigating platforms safely</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Cyberbullying</CardTitle>
                  <CardDescription>Prevention and response strategies</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Malware & Viruses</CardTitle>
                  <CardDescription>Protecting devices from threats</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Gaming Safety</CardTitle>
                  <CardDescription>Staying safe while gaming online</CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>

        {/* For Educators */}
        <section className="py-16 px-4 bg-muted/30">
          <div className="container mx-auto max-w-6xl">
            <Card className="bg-background">
              <CardContent className="p-8 md:p-12">
                <div className="grid lg:grid-cols-2 gap-8 items-center">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <BookOpen className="h-8 w-8 text-primary" />
                      <h2 className="text-2xl font-bold">For Educators & Parents</h2>
                    </div>
                    <p className="text-muted-foreground mb-6">
                      CyberSafe Academy is designed to be used in classrooms, after-school programs, 
                      and at home. Our content aligns with digital literacy standards and can be 
                      easily integrated into existing curricula.
                    </p>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                        <span>Free to use for educational purposes</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                        <span>Self-paced learning for independent study</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                        <span>Interactive quizzes for assessment</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                        <span>Discussion prompts in every lesson</span>
                      </li>
                    </ul>
                    <Button asChild>
                      <Link href="/lessons">Start Teaching</Link>
                    </Button>
                  </div>
                  <div className="bg-muted/50 rounded-xl p-8">
                    <h3 className="font-semibold mb-4">How to Use CyberSafe Academy</h3>
                    <ol className="space-y-4">
                      <li className="flex gap-3">
                        <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">1</span>
                        <span className="text-muted-foreground">Browse lessons and select topics relevant to your students</span>
                      </li>
                      <li className="flex gap-3">
                        <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">2</span>
                        <span className="text-muted-foreground">Have students read lessons independently or as a group</span>
                      </li>
                      <li className="flex gap-3">
                        <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">3</span>
                        <span className="text-muted-foreground">Use discussion questions for class conversations</span>
                      </li>
                      <li className="flex gap-3">
                        <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">4</span>
                        <span className="text-muted-foreground">Assess understanding with interactive quizzes</span>
                      </li>
                    </ol>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Begin your journey to becoming cyber-safe today. Our lessons are free, 
              accessible, and designed specifically for you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg">
                <Link href="/lessons">Start Learning</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/quizzes">Take a Quiz</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
