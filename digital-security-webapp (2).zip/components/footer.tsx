import Link from 'next/link'
import { Shield } from 'lucide-react'

const footerLinks = {
  lessons: [
    { href: '/lessons/passwords', label: 'Passwords' },
    { href: '/lessons/phishing', label: 'Phishing' },
    { href: '/lessons/deepfakes', label: 'Deepfakes' },
    { href: '/lessons/privacy', label: 'Privacy' },
    { href: '/lessons/social-media', label: 'Social Media' },
    { href: '/lessons/cyberbullying', label: 'Cyberbullying' },
  ],
  resources: [
    { href: '/quizzes', label: 'Quizzes' },
    { href: '/resources', label: 'Resources' },
    { href: '/about', label: 'About' },
  ],
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-2 text-xl font-bold">
              <Shield className="h-7 w-7 text-primary" />
              <span className="gradient-text">CyberSafe Academy</span>
            </Link>
            <p className="mt-4 max-w-md text-sm text-muted-foreground">
              Empowering students aged 10-18 with essential digital security skills. 
              Learn to protect yourself online through interactive lessons and practical examples.
            </p>
          </div>

          {/* Lessons */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-foreground">
              Lessons
            </h3>
            <ul className="mt-4 space-y-2">
              {footerLinks.lessons.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-foreground">
              Resources
            </h3>
            <ul className="mt-4 space-y-2">
              {footerLinks.resources.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-8">
          <p className="text-center text-sm text-muted-foreground">
            Disclaimer: The content on CyberSafe Academy is for educational purposes only. 
            Always consult with parents, teachers, or trusted adults when dealing with online safety concerns.
          </p>
          <p className="mt-4 text-center text-xs text-muted-foreground">
            Built for students, by students. Stay safe online.
          </p>
        </div>
      </div>
    </footer>
  )
}
