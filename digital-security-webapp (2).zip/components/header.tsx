'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Menu, X, Shield, ChevronDown } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

const lessons = [
  { href: '/lessons/passwords', label: 'Passwords & Authentication' },
  { href: '/lessons/phishing', label: 'Phishing & Scams' },
  { href: '/lessons/deepfakes', label: 'Deepfakes & Misinformation' },
  { href: '/lessons/privacy', label: 'Privacy & Personal Data' },
  { href: '/lessons/social-media', label: 'Social Media Safety' },
  { href: '/lessons/cyberbullying', label: 'Cyberbullying & Online Harassment' },
  { href: '/lessons/malware', label: 'Malware & Viruses' },
  { href: '/lessons/gaming-safety', label: 'Gaming & Online Safety' },
]

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2 text-xl font-bold">
          <Shield className="h-7 w-7 text-primary" />
          <span className="gradient-text">CyberSafe Academy</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden items-center gap-6 md:flex">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-1">
                Lessons <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-64">
              {lessons.map((lesson) => (
                <DropdownMenuItem key={lesson.href} asChild>
                  <Link href={lesson.href} className="w-full cursor-pointer">
                    {lesson.label}
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Link href="/quizzes" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
            Quizzes
          </Link>
          <Link href="/resources" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
            Resources
          </Link>
          <Link href="/about" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
            About
          </Link>
          <Button asChild className="glow-primary">
            <Link href="/lessons/passwords">Start Learning</Link>
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </nav>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="border-t border-border bg-background md:hidden">
          <div className="space-y-1 px-4 py-4">
            <div className="pb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Lessons
            </div>
            {lessons.map((lesson) => (
              <Link
                key={lesson.href}
                href={lesson.href}
                className="block rounded-md px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary"
                onClick={() => setMobileMenuOpen(false)}
              >
                {lesson.label}
              </Link>
            ))}
            <div className="my-4 border-t border-border" />
            <Link
              href="/quizzes"
              className="block rounded-md px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary"
              onClick={() => setMobileMenuOpen(false)}
            >
              Quizzes
            </Link>
            <Link
              href="/resources"
              className="block rounded-md px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary"
              onClick={() => setMobileMenuOpen(false)}
            >
              Resources
            </Link>
            <Link
              href="/about"
              className="block rounded-md px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary"
              onClick={() => setMobileMenuOpen(false)}
            >
              About
            </Link>
            <Button asChild className="mt-4 w-full">
              <Link href="/lessons/passwords">Start Learning</Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  )
}
