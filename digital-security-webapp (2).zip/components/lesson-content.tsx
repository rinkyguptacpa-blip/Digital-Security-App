import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertTriangle, CheckCircle, Info, XCircle } from 'lucide-react'
import { ReactNode } from 'react'

interface ContentCardProps {
  type: 'info' | 'warning' | 'success' | 'danger' | 'example'
  title: string
  children: ReactNode
}

export function ContentCard({ type, title, children }: ContentCardProps) {
  const styles = {
    info: {
      icon: Info,
      bgColor: 'bg-primary/5 border-primary/30',
      iconColor: 'text-primary',
      titleColor: 'text-primary',
    },
    warning: {
      icon: AlertTriangle,
      bgColor: 'bg-warning/5 border-warning/30',
      iconColor: 'text-warning',
      titleColor: 'text-warning',
    },
    success: {
      icon: CheckCircle,
      bgColor: 'bg-accent/5 border-accent/30',
      iconColor: 'text-accent',
      titleColor: 'text-accent',
    },
    danger: {
      icon: XCircle,
      bgColor: 'bg-destructive/5 border-destructive/30',
      iconColor: 'text-destructive',
      titleColor: 'text-destructive',
    },
    example: {
      icon: Info,
      bgColor: 'bg-secondary border-border',
      iconColor: 'text-muted-foreground',
      titleColor: 'text-foreground',
    },
  }

  const { icon: Icon, bgColor, iconColor, titleColor } = styles[type]

  return (
    <Card className={`my-6 ${bgColor}`}>
      <CardHeader className="pb-2">
        <CardTitle className={`flex items-center gap-2 text-base ${titleColor}`}>
          <Icon className={`h-5 w-5 ${iconColor}`} />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">{children}</CardContent>
    </Card>
  )
}

interface ExampleBoxProps {
  title: string
  good?: boolean
  children: ReactNode
}

export function ExampleBox({ title, good, children }: ExampleBoxProps) {
  return (
    <div
      className={`my-4 rounded-lg border p-4 ${
        good === undefined
          ? 'border-border bg-secondary/50'
          : good
            ? 'border-accent/30 bg-accent/5'
            : 'border-destructive/30 bg-destructive/5'
      }`}
    >
      <div className="mb-2 flex items-center gap-2 text-sm font-medium">
        {good !== undefined && (
          good ? (
            <CheckCircle className="h-4 w-4 text-accent" />
          ) : (
            <XCircle className="h-4 w-4 text-destructive" />
          )
        )}
        <span className={good === undefined ? 'text-foreground' : good ? 'text-accent' : 'text-destructive'}>
          {title}
        </span>
      </div>
      <div className="text-sm text-muted-foreground">{children}</div>
    </div>
  )
}

interface QuickFactProps {
  children: ReactNode
}

export function QuickFact({ children }: QuickFactProps) {
  return (
    <div className="my-4 flex items-start gap-3 rounded-lg bg-primary/10 p-4">
      <Info className="h-5 w-5 shrink-0 text-primary mt-0.5" />
      <p className="text-sm">{children}</p>
    </div>
  )
}

// Rinky deleted lines suggested by Claude
// Section
export function Section({ children }: { children: ReactNode }) {
  return <div className="space-y-4">{children}</div>
}

// Paragraph
export function Paragraph({ children }: { children: ReactNode }) {
  return <p className="text-sm text-muted-foreground leading-relaxed">{children}</p>
}

// BulletList
export function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="my-4 space-y-2">
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  )
}

// NumberedList
export function NumberedList({ items }: { items: string[] }) {
  return <StepList steps={items} />
}

// WarningBox
export function WarningBox({ title, children }: { title: string; children: ReactNode }) {
  return <ContentCard type="warning" title={title}>{children}</ContentCard>
}

// TipBox
export function TipBox({ title, children }: { title: string; children: ReactNode }) {
  return <ContentCard type="success" title={title}>{children}</ContentCard>
}

// QuizQuestion
export function QuizQuestion({ question, options, correctIndex, explanation }: {
  question: string
  options: string[]
  correctIndex: number
  explanation: string
}) {
  return (
    <div className="my-6 rounded-lg border border-border bg-card p-6">
      <p className="font-semibold mb-4">{question}</p>
      <ol className="space-y-2 mb-4">
        {options.map((option, i) => (
          <li key={i} className={`rounded-md border px-3 py-2 text-sm ${
            i === correctIndex
              ? "border-primary/40 bg-primary/10 text-primary"
              : "border-border text-muted-foreground"
          }`}>
            <span className="font-medium mr-2">{String.fromCharCode(65 + i)}.</span>
            {option}
          </li>
        ))}
      </ol>
      <div className="rounded-md bg-secondary/50 px-3 py-2 text-sm text-muted-foreground">
        <span className="font-medium text-foreground">Explanation: </span>
        {explanation}
      </div>
    </div>
  )
}
export function StepList({ steps }: { steps: string[] }) {
  return (
    <ol className="my-4 space-y-3">
      {steps.map((step, index) => (
        <li key={index} className="flex items-start gap-3">
          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
            {index + 1}
          </span>
          <span className="text-sm text-muted-foreground pt-0.5">{step}</span>
        </li>
      ))}
    </ol>
  )
}