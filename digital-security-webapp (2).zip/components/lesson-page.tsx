import Link from 'next/link'
import { ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, ArrowRight, Clock, BookOpen, LucideIcon } from 'lucide-react'

interface LessonSection {
  id: string
  title: string
  content: ReactNode
}

interface LessonPageProps {
  title: string
  description: string
  icon?: LucideIcon
  duration: string
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced'
  sections?: LessonSection[]
  prevLesson?: { href: string; title: string }
  nextLesson?: { href: string; title: string }
  quizHref?: string
}

export function LessonPage({
  title,
  description,
  icon: Icon,
  duration,
  difficulty,
  sections,
  children,
  prevLesson,
  nextLesson,
  quizHref,
}: LessonPageProps & { children?: ReactNode }) {
  const difficultyColor = {
    Beginner: 'bg-accent/20 text-accent',
    Intermediate: 'bg-warning/20 text-warning',
    Advanced: 'bg-destructive/20 text-destructive',
  }

  return (
    <div className="px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </div>

        {/* Lesson Header */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-4">
            {Icon && (
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10">
                <Icon className="h-7 w-7 text-primary" />
              </div>
            )}
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary" className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {duration}
              </Badge>
              <Badge className={difficultyColor[difficulty]}>{difficulty}</Badge>
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">{title}</h1>
          <p className="mt-4 text-lg text-muted-foreground">{description}</p>
        </div>

        {/* Table of Contents */}
        {sections && (
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <BookOpen className="h-5 w-5" />
                In This Lesson
              </CardTitle>
            </CardHeader>
            <CardContent>
              <nav>
                <ol className="space-y-2">
                  {sections.map((section, index) => (
                    <li key={section.id}>

                      href={`#${section.id}`}
                      className="flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors hover:bg-secondary"
              >
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                        {index + 1}
                      </span>
                      {section.title}
                    </a>
            </li>
          ))}
              </ol>
            </nav>
          </CardContent>
  </Card>
)}

      {/* Lesson Content */}
      <div className="prose prose-invert max-w-none">
        {sections ? sections.map((section, index) => (
          <section key={section.id} id={section.id} className="mb-12 scroll-mt-24">
            <div className="flex items-center gap-3 mb-6">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                {index + 1}
              </span>
              <h2 className="text-2xl font-bold m-0">{section.title}</h2>
            </div>
            <div className="pl-11">{section.content}</div>
          </section>
        )) : children}
        <section key={section.id} id={section.id} className="mb-12 scroll-mt-24">
          <div className="flex items-center gap-3 mb-6">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
              {index + 1}
            </span>
            <h2 className="text-2xl font-bold m-0">{section.title}</h2>
          </div>
          <div className="pl-11">{section.content}</div>
        </section>
          ))}
      </div>

      {/* Quiz CTA */}
      <Card className="mb-12 border-primary/50 bg-primary/5">
        <CardContent className="flex flex-col items-center justify-between gap-4 p-6 sm:flex-row">
          <div>
            <h3 className="text-lg font-semibold">Ready to Test Your Knowledge?</h3>
            <p className="text-sm text-muted-foreground">
              Take the quiz to see how much you have learned from this lesson.
            </p>
          </div>
          <Button asChild>
            <Link href={quizHref}>Take Quiz</Link>
          </Button>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between gap-4 border-t border-border pt-8">
        {prevLesson ? (
          <Button asChild variant="outline">
            <Link href={prevLesson.href} className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">{prevLesson.title}</span>
              <span className="sm:hidden">Previous</span>
            </Link>
          </Button>
        ) : (
          <div />
        )}
        {nextLesson ? (
          <Button asChild>
            <Link href={nextLesson.href} className="flex items-center gap-2">
              <span className="hidden sm:inline">{nextLesson.title}</span>
              <span className="sm:hidden">Next</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        ) : (
          <Button asChild>
            <Link href="/quizzes">View All Quizzes</Link>
          </Button>
        )}
      </div>
    </div>
    </div >
  )
}
